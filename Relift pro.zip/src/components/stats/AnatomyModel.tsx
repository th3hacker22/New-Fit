import React from "react";
import { motion } from "framer-motion";
import { FRONT, BACK, FRONT_BODY, BACK_BODY } from "../AnatomyMap";

interface AnatomyModelProps {
  muscleLevels: Record<string, number>; // values 0 to 100
  view: "front" | "back" | "both";
  highlightColor?: "red" | "green" | "cyan" | "yellow";
  isAr?: boolean;
}

// Maps any premium muscle group ID to one of the 6 primary categories
const getCategoryForMuscleId = (id: string): string => {
  const lowercaseId = id.toLowerCase();
  
  if (lowercaseId.includes("chest")) return "Chest";
  if (
    lowercaseId.includes("traps") ||
    lowercaseId.includes("back") ||
    lowercaseId.includes("lats") ||
    lowercaseId.includes("neck")
  ) {
    return "Back";
  }
  if (
    lowercaseId.includes("quad") ||
    lowercaseId.includes("femoris") ||
    lowercaseId.includes("vmo") ||
    lowercaseId.includes("adductor") ||
    lowercaseId.includes("gastrocnemius") ||
    lowercaseId.includes("tibialis") ||
    lowercaseId.includes("soleus") ||
    lowercaseId.includes("glute") ||
    lowercaseId.includes("ham") ||
    lowercaseId.includes("gastroc")
  ) {
    return "Legs";
  }
  if (lowercaseId.includes("delt")) return "Shoulders";
  if (
    lowercaseId.includes("biceps") ||
    lowercaseId.includes("forearm") ||
    lowercaseId.includes("triceps")
  ) {
    return "Arms";
  }
  if (
    lowercaseId.includes("abs") ||
    lowercaseId.includes("obliques") ||
    lowercaseId.includes("core")
  ) {
    return "Core";
  }
  return "";
};

export default function AnatomyModel({
  muscleLevels,
  view = "both",
  highlightColor = "green",
  isAr = false,
}: AnatomyModelProps) {
  // Helper to resolve color based on recovery percentage or workout active status
  const getMuscleColor = (id: string) => {
    // Try to get specific muscle level first, then fall back to category
    const category = getCategoryForMuscleId(id);
    const level = muscleLevels[id] ?? muscleLevels[category] ?? 0;
    
    const inactiveColor = "rgba(75, 85, 99, 0.15)"; // subtle gray for definition
    
    if (level === 0 && !muscleLevels[category]) return inactiveColor;
    
    // 1. Worked-intensity mode (highlightColor === "red")
    if (highlightColor === "red") {
      if (level === 0) return inactiveColor;
      return `rgba(101, 163, 13, ${(0.3 + (level / 100) * 0.7).toFixed(2)})`;
    }

    // 2. Recovery theme mode
    if (level === 0) return "rgba(220, 38, 38, 0.6)"; 
    if (level === 100) return "rgba(101, 163, 13, 0.8)";
    
    if (level >= 90) return "rgba(101, 163, 13, 0.8)";
    if (level >= 60) return "rgba(217, 119, 6, 0.7)";
    return "rgba(220, 38, 38, 0.7)";
  };

  const drawFront = () => (
    <svg viewBox="0 0 676.49 1203.49" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto max-h-[220px] md:max-h-[280px] mx-auto">
      {/* Detailed Front Muscles */}
      {FRONT.map((m) => {
        const fillCol = getMuscleColor(m.id);
        const isActive = fillCol.includes("rgba(101, 163, 13") || fillCol.includes("rgba(217, 119, 6") || fillCol.includes("rgba(220, 38, 38");
        return (
          <g key={m.id}>
            {m.paths.map((d, i) => (
              <path
                key={i}
                d={d}
                fill={fillCol}
                stroke={isActive ? "rgba(255,255,255,0.15)" : "rgba(107, 114, 128, 0.2)"}
                strokeWidth={1.5}
                strokeLinejoin="round"
                style={{ transition: "all 0.3s ease" }}
              />
            ))}
          </g>
        );
      })}
      {/* Body Outline Over the muscles for better definition */}
      <g opacity="0.3">
        {FRONT_BODY.map((d, i) => (
          <path key={i} d={d} fill="none" stroke="rgba(107, 114, 128, 0.5)" strokeWidth="2" />
        ))}
      </g>
    </svg>
  );

  const drawBack = () => (
    <svg viewBox="0 0 676.49 1203.49" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto max-h-[220px] md:max-h-[280px] mx-auto">
      {/* Detailed Back Muscles */}
      {BACK.map((m) => {
        const fillCol = getMuscleColor(m.id);
        const isActive = fillCol.includes("rgba(101, 163, 13") || fillCol.includes("rgba(217, 119, 6") || fillCol.includes("rgba(220, 38, 38");
        return (
          <g key={m.id}>
            {m.paths.map((d, i) => (
              <path
                key={i}
                d={d}
                fill={fillCol}
                stroke={isActive ? "rgba(255,255,255,0.15)" : "rgba(107, 114, 128, 0.2)"}
                strokeWidth={1.5}
                strokeLinejoin="round"
                style={{ transition: "all 0.3s ease" }}
              />
            ))}
          </g>
        );
      })}
      {/* Body Outline */}
      <g opacity="0.3">
        {BACK_BODY.map((d, i) => (
          <path key={i} d={d} fill="none" stroke="rgba(107, 114, 128, 0.5)" strokeWidth="2" />
        ))}
      </g>
    </svg>
  );

  return (
    <div className="flex flex-row justify-center items-center gap-4 md:gap-8 w-full p-2 select-none">
      {(view === "front" || view === "both") && (
        <div className="flex flex-col items-center flex-1 max-w-[140px]">
          <span className="text-[10px] text-text-muted font-extrabold tracking-widest uppercase mb-2">
            {isAr ? "الأمام" : "ANTERIOR"}
          </span>
          <div className="w-full border border-border bg-bg-surface-hover rounded-2xl p-2 md:p-3 shadow-inner backdrop-blur-md">
            {drawFront()}
          </div>
        </div>
      )}
      {(view === "back" || view === "both") && (
        <div className="flex flex-col items-center flex-1 max-w-[140px]">
          <span className="text-[10px] text-text-muted font-extrabold tracking-widest uppercase mb-2">
            {isAr ? "الخلف" : "POSTERIOR"}
          </span>
          <div className="w-full border border-border bg-bg-surface-hover rounded-2xl p-2 md:p-3 shadow-inner backdrop-blur-md">
            {drawBack()}
          </div>
        </div>
      )}
    </div>
  );
}
