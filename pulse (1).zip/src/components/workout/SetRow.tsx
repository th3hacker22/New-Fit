import { memo } from "react";
import { motion } from "framer-motion";
import { Check, Trash2 } from "lucide-react";
import { cn } from "@/utils/cn";
import type { WorkoutSet } from "@/store/useWorkoutStore";

interface SetRowProps {
  set: WorkoutSet;
  setIndex: number;
  exerciseIndex: number;
  ghostWeight?: number;
  ghostReps?: number;
  onToggleComplete: () => void;
  onUpdateWeight: (value: string) => void;
  onUpdateReps: (value: string) => void;
  onUpdateRpe?: (value: string) => void;
  onRemoveSet?: () => void;
  onUpdateSetType?: (value: "normal" | "warmup" | "right" | "left" | "failure" | "drop" | "negative" | "partial" | "myoreps" | "feeder" | "top" | "backoff") => void;
}

const SetRow = memo(
  ({
    set,
    setIndex,
    ghostWeight,
    ghostReps,
    onToggleComplete,
    onUpdateWeight,
    onUpdateReps,
    onUpdateRpe,
    onRemoveSet,
    onUpdateSetType,
  }: SetRowProps) => {
    const isCompleted = set.completed;
    const setType = set.setType || "normal";

    let badgeLabel = String(setIndex + 1);
    let badgeColorClass = "bg-bg-elevated text-text-muted hover:bg-bg-hover";

    if (setType === "warmup") {
      badgeLabel = "W";
      badgeColorClass = "bg-amber-500/20 text-amber-500 border border-amber-500/30 hover:bg-amber-500/30";
    } else if (setType === "right") {
      badgeLabel = "R";
      badgeColorClass = "bg-orange-500/20 text-orange-400 border border-orange-500/30 hover:bg-orange-500/30";
    } else if (setType === "left") {
      badgeLabel = "L";
      badgeColorClass = "bg-lime-500/20 text-lime-400 border border-lime-500/30 hover:bg-lime-500/30";
    } else if (setType === "failure") {
      badgeLabel = "F";
      badgeColorClass = "bg-rose-500/20 text-rose-400 border border-rose-500/30 hover:bg-rose-500/30";
    } else if (setType === "drop") {
      badgeLabel = "D";
      badgeColorClass = "bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 hover:bg-cyan-500/30";
    } else if (setType === "negative") {
      badgeLabel = "N";
      badgeColorClass = "bg-fuchsia-500/20 text-fuchsia-400 border border-fuchsia-500/30 hover:bg-fuchsia-500/30";
    } else if (setType === "partial") {
      badgeLabel = "P";
      badgeColorClass = "bg-pink-500/20 text-pink-400 border border-pink-500/30 hover:bg-pink-500/30";
    } else if (setType === "myoreps") {
      badgeLabel = "M";
      badgeColorClass = "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 hover:bg-indigo-500/30";
    } else if (setType === "feeder") {
      badgeLabel = "E";
      badgeColorClass = "bg-sky-500/20 text-sky-400 border border-sky-500/30 hover:bg-sky-500/30";
    } else if (setType === "top") {
      badgeLabel = "T";
      badgeColorClass = "bg-purple-500/20 text-purple-400 border border-purple-500/30 hover:bg-purple-500/30";
    } else if (setType === "backoff") {
      badgeLabel = "B";
      badgeColorClass = "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30";
    } else if (isCompleted) {
      badgeColorClass = "bg-success/15 text-success border border-success/30";
    }

    return (
      <motion.div
        layout
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: "auto" }}
        exit={{ opacity: 0, height: 0 }}
        className={cn(
          "grid grid-cols-[2rem_1fr_1fr_3rem_3rem_2rem] gap-2 px-4 py-2.5 transition-colors duration-300 items-center",
          isCompleted ? "bg-success/5" : "bg-transparent",
        )}
      >
        <div className="flex items-center justify-center relative">
          <span
            className={cn(
              "flex h-7 w-7 items-center justify-center rounded-lg text-xs font-black transition-all duration-200",
              badgeColorClass,
            )}
          >
            {badgeLabel}
          </span>
          <select
            value={setType}
            onChange={(e) => onUpdateSetType && onUpdateSetType(e.target.value as any)}
            disabled={isCompleted}
            className="absolute inset-0 opacity-0 w-full h-full cursor-pointer disabled:cursor-not-allowed"
            title="Set type"
          >
            <option value="normal">مجموعة عادية</option>
            <option value="warmup">Warmup Set (W)</option>
            <option value="right">Right Arm/Leg Set (R)</option>
            <option value="left">Left Arm/Leg Set (L)</option>
            <option value="failure">Failure Set (F)</option>
            <option value="drop">دروب سيت (D)</option>
            <option value="negative">تكرار سلبي (N)</option>
            <option value="partial">تكرار جزئي (P)</option>
            <option value="myoreps">مايو ريبس (M)</option>
            <option value="feeder">Feeder Set (E)</option>
            <option value="top">أعلى وزن (T)</option>
            <option value="backoff">تخفيف وزن (B)</option>
          </select>
        </div>

        <input
          type="number"
          inputMode="decimal"
          value={set.weight}
          onChange={(e) => onUpdateWeight(e.target.value)}
          placeholder={ghostWeight != null ? String(ghostWeight) : ""}
          readOnly={isCompleted}
          className={cn(
            "w-full min-w-0 px-1 h-10 rounded-xl border text-center text-sm font-semibold outline-none transition-all duration-200",
            isCompleted
              ? "border-success/20 bg-success/5 text-success"
              : "border-border bg-bg-elevated text-text-primary placeholder-text-muted/40 focus:border-primary focus:ring-1 focus:ring-primary",
          )}
        />

        <input
          type="number"
          inputMode="numeric"
          value={set.reps}
          onChange={(e) => onUpdateReps(e.target.value)}
          placeholder={ghostReps != null ? String(ghostReps) : ""}
          readOnly={isCompleted}
          className={cn(
            "w-full min-w-0 px-1 h-10 rounded-xl border text-center text-sm font-semibold outline-none transition-all duration-200",
            isCompleted
              ? "border-success/20 bg-success/5 text-success"
              : "border-border bg-bg-elevated text-text-primary placeholder-text-muted/40 focus:border-primary focus:ring-1 focus:ring-primary",
          )}
        />

        <input
          type="number"
          inputMode="numeric"
          value={set.rpe || ""}
          onChange={(e) => onUpdateRpe && onUpdateRpe(e.target.value)}
          placeholder="RPE"
          readOnly={isCompleted}
          className={cn(
            "w-full min-w-0 px-1 h-10 rounded-xl border text-center text-xs font-semibold outline-none transition-all duration-200",
            isCompleted
              ? "border-success/20 bg-success/5 text-success"
              : "border-border bg-bg-elevated text-text-primary placeholder-text-muted/40 focus:border-primary focus:ring-1 focus:ring-primary",
          )}
        />

        <div className="flex items-center justify-center">
          <motion.button
            onClick={onToggleComplete}
            className={cn(
              "flex h-10 w-10 items-center justify-center rounded-xl transition-all duration-200 active:scale-90",
              isCompleted
                ? "bg-success text-white shadow-lg shadow-success/25"
                : "border border-border bg-bg-elevated text-text-muted hover:border-success/40 hover:text-success",
            )}
            whileTap={{ scale: 0.85 }}
          >
            <Check className="h-5 w-5" strokeWidth={isCompleted ? 3 : 2} />
          </motion.button>
        </div>

        <div className="flex items-center justify-center">
          <button
            onClick={onRemoveSet}
            disabled={isCompleted}
            className="text-text-muted hover:text-danger disabled:opacity-30 transition-colors p-1"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </motion.div>
    );
  },
);

SetRow.displayName = "SetRow";

export default SetRow;
