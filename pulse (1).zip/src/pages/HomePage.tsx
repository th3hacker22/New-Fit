import { useState, useEffect } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import {
  Flame,
  Target,
  TrendingUp,
  ChevronRight,
  Zap,
  Dumbbell,
  Clock,
  Plus,
  Play,
  Trash2,
  Copy,
  Activity,
  Heart,
} from "lucide-react";
import { cn } from "@/utils/cn";
import { getWorkoutStreak, getTotalStats, db } from "@/db";
import { useRoutineStore } from "@/store/useRoutineStore";
import { useWorkoutStore } from "@/store/useWorkoutStore";
import { useAuthStore } from "@/store/useAuthStore";
import { useExerciseStore } from "@/store/useExerciseStore";
import { useAchievementsStore } from "@/store/useAchievementsStore";
import { useSettingsStore } from "@/store/useSettingsStore";
import { useSocialStore } from "@/store/useSocialStore";
import AchievementBadge from "@/components/AchievementBadge";
import { DataEmptyState } from "@/components/ui/DataEmptyState";
import { Button } from "@/components/ui/Button";
import { ACHIEVEMENTS } from "@/data/achievements";
import {
  routineTemplates,
  buildTemplateRoutine,
} from "@/data/routineTemplates";
import { uid } from "@/utils/id";
import { FeedPost } from "@/services/socialService";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.5, ease: "easeOut" as const },
  }),
};

export default function HomePage() {
  const navigate = useNavigate();
  const [streak, setStreak] = useState(0);
  const [totalStats, setTotalStats] = useState({
    totalWorkouts: 0,
    totalVolume: 0,
    totalDuration: 0,
  });
  const [recentWorkouts, setRecentWorkouts] = useState<
    { id: string; name: string; date: string; exerciseCount: number }[]
  >([]);
  const [muscleRecovery, setMuscleRecovery] = useState<{ [key: string]: { percent: number; hoursLeft: number } }>({});
  const [activityTab, setActivityTab] = useState<"local" | "social">("local");

  const routines = useRoutineStore((s) => s.routines);
  const loadRoutines = useRoutineStore((s) => s.loadRoutines);
  const deleteRoutine = useRoutineStore((s) => s.deleteRoutine);
  const saveRoutine = useRoutineStore((s) => s.saveRoutine);
  const startWorkout = useWorkoutStore((s) => s.startWorkout);
  const user = useAuthStore((s) => s.user);

  const { language } = useSettingsStore();
  const isAr = language === "ar";

  const exercises = useExerciseStore((s) => s.exercises);
  const loadExercises = useExerciseStore((s) => s.loadExercises);

  const { newlyUnlocked, clearNewlyUnlocked } = useAchievementsStore();

  // ── Social Store For Live Community Activity ──
  const {
    feed,
    loadFollowing,
    loadFeed,
    giveKudos,
    isLoading: isSocialLoading,
  } = useSocialStore();

  useEffect(() => {
    loadRoutines();
    loadExercises();
  }, [loadRoutines, loadExercises]);

  useEffect(() => {
    async function loadData() {
      const [streakData, statsData, sessions] = await Promise.all([
        getWorkoutStreak(),
        getTotalStats(),
        db.workoutSessions.orderBy("date").reverse().limit(3).toArray(),
      ]);

      setStreak(streakData);
      setTotalStats(statsData);
      setRecentWorkouts(
        sessions.map((s) => ({
          id: s.id,
          name: s.name,
          date: s.date,
          exerciseCount: s.exercises.length,
        })),
      );

      // Compute Muscle Recovery based on workout history
      const allSessions = await db.workoutSessions.where("completed").equals(1).toArray();
      const MUSCLE_GROUPS = ["Chest", "Back", "Legs", "Shoulders", "Arms", "Core"];
      const recoveryMap: { [key: string]: { percent: number; hoursLeft: number } } = {};

      for (const muscle of MUSCLE_GROUPS) {
        const latestSession = allSessions.find(s => {
          return s.exercises.some(ex => {
            const exerciseDef = exercises.find(e => String(e.id) === String(ex.exerciseId));
            if (exerciseDef) {
              const mGroup = exerciseDef.muscleGroup?.toLowerCase() || "";
              const target = exerciseDef.target?.toLowerCase() || "";
              const secondary = exerciseDef.secondaryMuscles?.map(sm => sm.toLowerCase()) || [];
              const search = muscle.toLowerCase();
              
              if (search === "legs") {
                return mGroup.includes("quads") || mGroup.includes("hamstrings") || mGroup.includes("glutes") || mGroup.includes("calves") || target.includes("quad") || target.includes("hamstring");
              }
              if (search === "arms") {
                return mGroup.includes("biceps") || mGroup.includes("triceps") || mGroup.includes("forearms") || target.includes("bicep") || target.includes("tricep");
              }
              if (search === "core") {
                return mGroup.includes("abs") || mGroup.includes("core") || target.includes("abs");
              }
              return mGroup.includes(search) || target.includes(search) || secondary.some(s => s.includes(search));
            }
            return false;
          });
        });

        if (!latestSession) {
          recoveryMap[muscle] = { percent: 100, hoursLeft: 0 };
        } else {
          const hoursElapsed = (Date.now() - new Date(latestSession.date).getTime()) / 3600000;
          const hoursLeft = Math.max(0, 48 - hoursElapsed);
          const percent = Math.min(100, Math.round((hoursElapsed / 48) * 100));
          recoveryMap[muscle] = { percent, hoursLeft: Math.round(hoursLeft * 10) / 10 };
        }
      }
      setMuscleRecovery(recoveryMap);
    }
    if (exercises.length > 0) {
      loadData();
    }
  }, [exercises]);

  // Load social feed when community tab is active
  useEffect(() => {
    if (user && activityTab === "social") {
      loadFollowing(user.uid).then(() => loadFeed());
    }
  }, [user, activityTab, loadFollowing, loadFeed]);

  const formatVolume = (kg: number) => {
    if (kg >= 1000) return `${(kg / 1000).toFixed(1)}`;
    return `${kg}`;
  };

  // Safe exercise list builder with fallback exercises
  const getPostExercises = (post: FeedPost) => {
    if (post.exercises && post.exercises.length > 0) {
      return post.exercises;
    }
    const mockDb = [
      {
        exerciseId: "bench-press",
        exerciseName: isAr ? "ضغط بنش بالبار" : "Barbell Bench Press",
        setsCount: 3,
        imageUrl: "https://raw.githubusercontent.com/hasaneyldrm/exercises-dataset/main/exercises/Barbell_Bench_Press/images/0.jpg",
      },
      {
        exerciseId: "squat",
        exerciseName: isAr ? "سكوات بالبار" : "Barbell Squat",
        setsCount: 3,
        imageUrl: "https://raw.githubusercontent.com/hasaneyldrm/exercises-dataset/main/exercises/Barbell_Squat/images/0.jpg",
      },
      {
        exerciseId: "lat-pulldown",
        exerciseName: isAr ? "سحب ظهر واسع" : "Cable Wide-Grip Lat Pulldown",
        setsCount: 4,
        imageUrl: "https://raw.githubusercontent.com/hasaneyldrm/exercises-dataset/main/exercises/Cable_Wide-Grip_Lat_Pulldown/images/0.jpg",
      },
    ];
    return mockDb.slice(0, post.exercisesCount || 3);
  };

  const formatFeedDuration = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    return isAr ? `${m} د` : `${m} min`;
  };

  const formatFeedVolume = (volume: number) => {
    if (isAr) {
      if (volume >= 1000) return `${(volume / 1000).toFixed(1)} طن`;
      return `${volume} كجم`;
    }
    if (volume >= 1000) return `${(volume / 1000).toFixed(1)}k kg`;
    return `${volume} kg`;
  };

  // Translations Map
  const t = {
    welcome: isAr ? "أهلاً بيك في ري‌ليفت يا بطل ⚡" : "Welcome to ReLift",
    keepPushing: isAr ? "عاش يا وحش، كمل طريقك! 🔥" : "Keep Pushing Forward!",
    startJourney: isAr ? "إبدأ فورمتك معانا 🚀" : "Start Your Fitness Journey",
    crushedWorkouts: (count: number) => isAr ? `قفلت ${count} تمرينة لحد دلوقتي. عاش يا بطل!` : `You've crushed ${count} workouts so far. Keep it up!`,
    trackWorkouts: isAr ? "سجل تمارينك، ظبط أهدافك، وتابع فورمتك — كله في مكان واحد." : "Track workouts, crush goals, and monitor progress — all in one place.",
    startWorkoutNow: isAr ? "إبدأ التمرينة دلوقتي" : "Start Workout Now",
    streak: isAr ? "أيام متواصلة" : "Streak",
    workouts: isAr ? "التمارين" : "Workouts",
    volume: isAr ? "الوزن التوتال" : "Volume",
    days: isAr ? "أيام" : "Days",
    sessions: isAr ? "تمرينة" : "Sessions",
    ton: isAr ? "طن" : "Ton",
    kg: isAr ? "كجم" : "Kg",
    activeChallenge: isAr ? "تحدي الأبطال 🏆" : "Active Challenge",
    challengeDesc: isAr ? "قفل ١٠٠ تمرينة وخد لقب البطل" : "Reach 100 total workouts (Centurion)",
    generatorTitle: isAr ? "عمل تمرينة بالذكاء الاصطناعي 🔮" : "AI Workout Generator",
    generatorDesc: isAr ? "هنعملك فورمة في ثواني" : "Get a custom plan in seconds",
    tryNow: isAr ? "جرب دلوقتي" : "Try Now",
    muscleRecovery: isAr ? "استشفاء العضلات 🩺" : "Muscle Recovery Tracking",
    scienceModel: isAr ? "حالة العضلة بعد ٤٨ ساعة" : "48h Science Model",
    readyToLift: isAr ? "جاهزة للدمار" : "READY TO LIFT",
    hoursRemaining: (hours: number) => isAr ? `فاضل ${hours} ساعة` : `${hours}h remaining`,
    customRoutines: isAr ? "جداولك 📋" : "Custom Routines",
    buildNew: isAr ? "جدول جديد" : "Build New",
    exercisesCount: (count: number) => isAr ? `${count} تمارين` : `${count} Exercises`,
    start: isAr ? "ابدأ" : "Start",
    templates: isAr ? "جداول جاهزة" : "Templates",
    addToRoutines: isAr ? "إضافة إلى جداولي" : "Add to My Routines",
    recentActivity: isAr ? "آخر تمريناتك ⚡" : "Recent Activity",
    myActivityTab: isAr ? "تمريناتي" : "My Activity",
    socialFeedTab: isAr ? "أخبار الجيم 👥" : "Social Feed",
    viewAll: isAr ? "شوف كله" : "View All",
    noWorkoutsYet: isAr ? "لسه متمرنتش يا وحش" : "No Workouts Yet",
    startFirstWorkout: isAr ? "إبدأ أول تمرينة وهتلاقيها هنا" : "Start your first workout and it will appear here",
    statistics: isAr ? "أرقامك 📈" : "Statistics",
    bodyMetrics: isAr ? "قياسات جسمك ⚖️" : "Body Metrics",
    loadingSocial: isAr ? "بنجيب أخبار الجيم..." : "Loading ReLift Community Feed...",
    noSocialFeed: isAr ? "مفيش حد نزل حاجة لسه" : "No feed posts yet",
    noSocialDesc: isAr ? "تابع الوحوش من الاستكشاف عشان تشوف تمارينهم هنا!" : "Follow other athletes from the 'Explore' page to see their workouts here!",
    recordsLabel: isAr ? "مجاميع" : "Sets",
    volumeLabel: isAr ? "الحجم العضلي" : "Volume",
    durationLabel: isAr ? "المدة" : "Duration",
    kudos: isAr ? "دعم" : "Kudos",
  };

  const getMuscleLabel = (muscle: string) => {
    if (!isAr) return muscle;
    const map: { [key: string]: string } = {
      Chest: "الصدر",
      Back: "الظهر",
      Legs: "الأرجل",
      Shoulders: "الأكتاف",
      Arms: "الذراعين",
      Core: "البطن"
    };
    return map[muscle] || muscle;
  };

  const quickStats = [
    {
      label: t.streak,
      value: streak.toString(),
      unit: t.days,
      icon: Flame,
      color: "text-warning",
      bg: "bg-warning/10",
    },
    {
      label: t.workouts,
      value: totalStats.totalWorkouts.toString(),
      unit: t.sessions,
      icon: Target,
      color: "text-primary",
      bg: "bg-primary-muted",
    },
    {
      label: t.volume,
      value: formatVolume(totalStats.totalVolume),
      unit: totalStats.totalVolume >= 1000 ? t.ton : t.kg,
      icon: TrendingUp,
      color: "text-success",
      bg: "bg-success/10",
    },
  ];

  return (
    <div className="space-y-8 pb-12 animate-fade-in" dir={isAr ? "rtl" : "ltr"}>
      {/* ── Welcome Card ── */}
      <motion.div
        className="glass-card relative overflow-hidden rounded-[--radius-card] p-6 shadow-2xl"
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={0}
      >
        <div className="absolute inset-0 z-0 opacity-40 mix-blend-overlay">
          <img
            src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=1470&auto=format&fit=crop"
            alt="Muscular person lifting weights"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-bg-card to-transparent" />
        </div>
        <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-primary/20 blur-3xl z-0" />
        <div className="absolute -bottom-10 -right-10 h-32 w-32 rounded-full bg-primary/10 blur-2xl z-0" />

        <div className="relative z-10">
          <div className="mb-1 flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            <span className="text-sm font-black text-primary">
              {t.welcome}
            </span>
          </div>
          <h1 className="mb-2 text-2xl font-black text-text-primary">
            {totalStats.totalWorkouts > 0 ? t.keepPushing : t.startJourney}
          </h1>
          <p className="mb-5 text-sm leading-relaxed text-text-secondary">
            {totalStats.totalWorkouts > 0
              ? t.crushedWorkouts(totalStats.totalWorkouts)
              : t.trackWorkouts}
          </p>
          <Button
            variant="primary"
            className="w-max"
            onClick={() => navigate({ to: "/exercises" })}
          >
            {t.startWorkoutNow}
            <ChevronRight className={cn("h-4 w-4", isAr && "rotate-180")} />
          </Button>
        </div>
      </motion.div>

      {/* ── Newly Unlocked Achievements Toast ── */}
      {newlyUnlocked.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="glass-card flex flex-col gap-3 rounded-[--radius-card] p-4 border border-primary/40 bg-primary/5"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-primary uppercase tracking-wider">
              {isAr ? "تم فتح إنجاز جديد! 🏆" : "Achievement Unlocked!"}
            </h3>
            <button
              onClick={clearNewlyUnlocked}
              className="text-text-muted hover:text-text-primary"
            >
              ✕
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {newlyUnlocked.map((id) => {
              const ach = ACHIEVEMENTS.find((a) => a.id === id);
              if (!ach) return null;
              return (
                <AchievementBadge
                  key={id}
                  title={ach.title}
                  description={ach.description}
                  iconName={ach.iconName}
                  isUnlocked={true}
                  animate={true}
                />
              );
            })}
          </div>
        </motion.div>
      )}

      {/* ── Quick Stats Grid ── */}
      <motion.div
        className="grid grid-cols-3 gap-3"
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={1}
      >
        {quickStats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div
              key={i}
              className="glass-card flex flex-col items-center justify-center rounded-[--radius-card] p-3 text-center hover:border-border transition-colors"
            >
              <div className={cn("mb-2 rounded-full p-2", stat.bg)}>
                <Icon className={cn("h-5 w-5", stat.color)} />
              </div>
              <p className="text-lg font-black text-text-primary leading-none">
                {stat.value}
              </p>
              <p className="text-[10px] text-text-muted uppercase tracking-wider mt-1 font-bold">
                {stat.label}
              </p>
            </div>
          );
        })}
      </motion.div>

      {/* ── Active Challenge ── */}
      <motion.div
        className="glass-card rounded-[--radius-card] p-4 flex items-center justify-between border-l-2 border-l-warning"
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={2}
      >
        <div className="flex items-center gap-3">
          <div className="bg-warning/20 p-2 rounded-xl">
            <Target className="w-6 h-6 text-warning" />
          </div>
          <div>
            <h4 className="text-xs font-black text-text-muted uppercase tracking-wider">
              {t.activeChallenge}
            </h4>
            <p className="text-sm font-bold text-text-primary truncate max-w-[180px] sm:max-w-xs block">
              {t.challengeDesc}
            </p>
          </div>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-lg font-black text-warning">
            {totalStats.totalWorkouts}
            <span className="text-xs text-text-muted font-bold">/100</span>
          </span>
        </div>
      </motion.div>

      {/* ── AI Workout Generator ── */}
      <motion.div
        className="glass-card flex items-center justify-between rounded-[--radius-card] p-6 bg-gradient-to-r from-primary/20 to-transparent border border-primary/20"
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={3}
      >
        <div className="flex gap-4 items-center">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/20">
            <Zap className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
              {t.generatorTitle}
            </h3>
            <p className="text-xs text-text-secondary mt-1">
              {t.generatorDesc}
            </p>
          </div>
        </div>
        <Button
          variant="primary"
          size="sm"
          onClick={() => navigate({ to: "/wizard" })}
        >
          {t.tryNow}
        </Button>
      </motion.div>

      {/* ── Muscle Recovery Tracker bento block ── */}
      <motion.div
        className="glass-card rounded-[--radius-card] p-5 border border-border space-y-4"
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={3}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-primary" />
            <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
              {t.muscleRecovery} 🩺
            </h3>
          </div>
          <span className="text-[10px] text-text-muted font-bold uppercase tracking-wider bg-bg-surface-hover px-2.5 py-1 rounded-md">
            {t.scienceModel}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {Object.entries(muscleRecovery).map(([muscle, stats]) => {
            const isFresh = stats.percent === 100;
            const isSore = stats.percent < 40;

            let colorClass = "bg-primary";
            let textClass = "text-primary";
            let borderClass = "border-primary/20";
            if (isSore) {
              colorClass = "bg-red-500";
              textClass = "text-red-400";
              borderClass = "border-red-500/20";
            } else if (stats.percent < 100) {
              colorClass = "bg-yellow-500";
              textClass = "text-yellow-400";
              borderClass = "border-yellow-500/20";
            }

            return (
              <div
                key={muscle}
                className={cn(
                  "p-3 rounded-xl border bg-bg-surface-hover flex flex-col justify-between h-20 transition-all hover:bg-border/30",
                  borderClass
                )}
              >
                <div className="flex justify-between items-start">
                  <span className="text-xs font-black text-text-primary uppercase tracking-wider">
                    {getMuscleLabel(muscle)}
                  </span>
                  <span className={cn("text-xs font-mono font-black", textClass)}>
                    {stats.percent}%
                  </span>
                </div>
                <div className="space-y-1.5">
                  <div className="h-1.5 w-full bg-border rounded-full overflow-hidden">
                    <motion.div
                      className={cn("h-full rounded-full", colorClass)}
                      initial={{ width: 0 }}
                      animate={{ width: `${stats.percent}%` }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                    />
                  </div>
                  <p className="text-[9px] text-text-muted font-bold uppercase tracking-wider font-mono truncate">
                    {isFresh ? t.readyToLift : t.hoursRemaining(stats.hoursLeft)}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </motion.div>

      {/* ── Custom Routines ── */}
      <motion.div
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={4}
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-base font-black text-text-primary uppercase tracking-wider">
            {t.customRoutines}
          </h2>
          <Link
            to="/builder"
            className="flex items-center gap-1 text-xs font-black text-primary hover:text-primary-hover uppercase tracking-wider"
          >
            <Plus className="h-3 w-3" />
            {t.buildNew}
          </Link>
        </div>

        {routines.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
            {routines.map((routine, idx) => (
              <motion.div
                key={routine.id}
                className="glass-card flex flex-col gap-3 rounded-[--radius-card] p-4 relative group hover:border-border transition-colors"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 + idx * 0.1 }}
              >
                <button
                  onClick={() => deleteRoutine(routine.id, user?.uid)}
                  className={`absolute top-3 p-1.5 rounded-md bg-danger/10 text-danger opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-0 ${
                    isAr ? "left-3" : "right-3"
                  }`}
                  title="Delete Routine"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
                <div className="flex items-start justify-between">
                  <div className={cn(isAr ? "pl-8" : "pr-8")}>
                    <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
                      {routine.name}
                    </h3>
                    <p className="text-xs text-text-muted mt-1 font-bold">
                      {t.exercisesCount(routine.exercises.length)}
                    </p>
                  </div>
                </div>

                <Button
                  onClick={async () => {
                    const ids = routine.exercises.map((ex) =>
                      String(ex.exerciseId),
                    );
                    const sessionId = await startWorkout(ids);
                    navigate({
                      to: `/workout/$sessionId`,
                      params: { sessionId },
                    });
                  }}
                  variant="primary"
                  className="w-full mt-2"
                  icon={<Play className="h-4 w-4" />}
                >
                  {t.start}
                </Button>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="mb-6">
            <DataEmptyState
              icon={Plus}
              title={isAr ? "مفيش جداول ليك لسه" : "No custom routines yet"}
              description={isAr ? "اعمل جدول ليك عشان تبدأ تتمرن على طول." : "Create your first routine to quick-start your workouts."}
              actionLabel={t.buildNew}
              onAction={() => navigate({ to: "/builder" })}
            />
          </div>
        )}

        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-base font-black text-text-primary uppercase tracking-wider">
            {t.templates}
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          {routineTemplates.map((template, idx) => (
            <motion.div
              key={template.name}
              className="glass-card rounded-[--radius-card] overflow-hidden flex flex-col hover:border-border transition-all group"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 + idx * 0.1 }}
            >
              {template.imageUrl && (
                <div className="relative h-28 w-full overflow-hidden bg-bg-surface-hover">
                  <img
                    src={template.imageUrl}
                    alt={template.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-bg-surface via-bg-surface/20 to-transparent" />
                </div>
              )}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
                    {template.name}
                  </h3>
                  <p className="text-xs text-text-muted mt-1">
                    {template.description}
                  </p>
                </div>
                <Button
                  onClick={async () => {
                    if (exercises.length === 0) return;
                    const generated = buildTemplateRoutine(template, exercises);
                    await saveRoutine(
                      {
                        id: uid(),
                        name: generated.name,
                        exercises: generated.exercises,
                        createdAt: new Date().toISOString(),
                        updatedAt: new Date().toISOString(),
                      },
                      user?.uid,
                    );
                  }}
                  variant="outline"
                  className="w-full mt-4"
                  icon={<Copy className="h-4 w-4" />}
                >
                  {t.addToRoutines}
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* ── Togglable Activity Section ── */}
      <motion.div
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={5}
        className="space-y-4"
      >
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-border pb-2">
            <h2 className="text-base font-black text-text-primary uppercase tracking-wider">
              {t.recentActivity}
            </h2>
            {recentWorkouts.length > 0 && activityTab === "local" && (
              <Link
                to="/stats"
                className="text-xs font-black text-primary hover:text-primary-hover uppercase tracking-wider"
              >
                {t.viewAll}
              </Link>
            )}
          </div>

          {/* Activity Tabs Controller */}
          <div className="flex bg-bg-surface p-1 rounded-xl border border-border w-full">
            <button
              onClick={() => setActivityTab("local")}
              className={cn(
                "flex-1 py-2 text-xs font-black rounded-lg transition-all",
                activityTab === "local"
                  ? "bg-bg-surface-hover text-primary shadow-md"
                  : "text-text-muted hover:text-text-primary"
              )}
            >
              {t.myActivityTab}
            </button>
            <button
              onClick={() => setActivityTab("social")}
              className={cn(
                "flex-1 py-2 text-xs font-black rounded-lg transition-all",
                activityTab === "social"
                  ? "bg-bg-surface-hover text-primary shadow-md"
                  : "text-text-muted hover:text-text-primary"
              )}
            >
              {t.socialFeedTab}
            </button>
          </div>
        </div>

        {activityTab === "local" ? (
          recentWorkouts.length > 0 ? (
            <div className="space-y-3">
              {recentWorkouts.map((workout, idx) => (
                <motion.div
                  key={workout.id}
                  className="glass-card flex flex-row items-center gap-3 rounded-[--radius-card] p-4 hover:border-border transition-colors"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + idx * 0.1 }}
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-muted shrink-0">
                    <Dumbbell className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-text-primary truncate uppercase">
                      {workout.name}
                    </p>
                    <p className="text-xs text-text-muted font-bold">
                      {t.exercisesCount(workout.exerciseCount)} •{" "}
                      {new Date(workout.date).toLocaleDateString(isAr ? 'ar-EG' : undefined, {
                        day: "numeric",
                        month: "short",
                      })}
                    </p>
                  </div>
                  <Clock className="h-4 w-4 text-text-muted shrink-0" />
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="glass-card flex flex-col items-center justify-center gap-3 rounded-[--radius-card] border border-dashed border-border py-12">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-bg-elevated">
                <Target className="h-7 w-7 text-text-muted" />
              </div>
              <p className="text-sm font-bold text-text-muted">
                {t.noWorkoutsYet}
              </p>
              <p className="text-xs text-text-muted text-center max-w-[200px] font-semibold">
                {t.startFirstWorkout}
              </p>
            </div>
          )
        ) : (
          /* COMMUNITY SOCIAL FEED INTEGRATION ON HOME PAGE */
          <div className="space-y-4">
            {isSocialLoading ? (
              <div className="text-xs text-text-muted text-center py-8 flex flex-col items-center justify-center gap-2">
                <div className="animate-spin w-5 h-5 border-2 border-primary border-t-transparent rounded-full" />
                <span>{t.loadingSocial}</span>
              </div>
            ) : feed.length === 0 ? (
              <div className="glass-card flex flex-col items-center justify-center gap-3 rounded-[--radius-card] border border-dashed border-border py-12 text-center px-4">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-bg-elevated">
                  <Activity className="h-7 w-7 text-text-muted" />
                </div>
                <p className="text-sm font-bold text-text-muted">
                  {t.noSocialFeed}
                </p>
                <p className="text-xs text-text-muted max-w-[260px] leading-relaxed font-semibold">
                  {t.noSocialDesc}
                </p>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => navigate({ to: "/feed" })}
                >
                  {isAr ? "روح شوف الناس بتتمرن إزاي 👥" : "Go to Explore"}
                </Button>
              </div>
            ) : (
              <AnimatePresence>
                {feed.slice(0, 3).map((post) => (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={"home-feed-" + post.id}
                    className="bg-bg-surface-hover rounded-2xl p-4 border border-border flex flex-col gap-4 shadow-xl hover:border-border transition-colors"
                  >
                    {/* Post Author info */}
                    <div className="flex items-center gap-3">
                      {post.authorPhotoURL ? (
                        <img
                          src={post.authorPhotoURL}
                          alt={post.authorName}
                          className="w-10 h-10 rounded-full bg-bg-surface-hover object-cover border border-border"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-black text-xs">
                          {post.authorName.substring(0, 2).toUpperCase()}
                        </div>
                      )}
                      <div className="flex flex-col">
                        <span className="font-bold text-xs text-text-primary">
                          {post.authorName}
                        </span>
                        <span className="text-[9px] text-text-muted uppercase tracking-widest font-mono">
                          {new Date(post.createdAt).toLocaleDateString(isAr ? 'ar-EG' : undefined, {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                          })}
                        </span>
                      </div>
                    </div>

                    {/* Workout details card */}
                    <div className="bg-bg-surface/60 rounded-xl p-4 border border-border">
                      <h4 className="font-black text-text-primary capitalize text-sm mb-3">
                        {post.workoutTitle}
                      </h4>

                      {/* Stats strip */}
                      <div className="grid grid-cols-3 gap-2 py-1 border-b border-border pb-3">
                        <div className="flex flex-col gap-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-text-muted font-bold">
                            {t.recordsLabel}
                          </span>
                          <div className="flex items-center gap-1.5 text-xs text-text-primary font-mono font-black">
                            <Dumbbell className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                            <span>{post.exercisesCount}</span>
                          </div>
                        </div>
                        <div className="flex flex-col gap-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-text-muted font-bold">
                            {t.volumeLabel}
                          </span>
                          <div className="flex items-center gap-1.5 text-xs text-text-primary font-mono font-black">
                            <Activity className="w-3.5 h-3.5 text-warning shrink-0" />
                            <span>{formatFeedVolume(post.totalVolume)}</span>
                          </div>
                        </div>
                        <div className="flex flex-col gap-0.5">
                          <span className="text-[9px] uppercase tracking-wider text-text-muted font-bold">
                            {t.durationLabel}
                          </span>
                          <div className="flex items-center gap-1.5 text-xs text-text-primary font-mono font-black">
                            <Clock className="w-3.5 h-3.5 text-primary shrink-0" />
                            <span>{formatFeedDuration(post.duration)}</span>
                          </div>
                        </div>
                      </div>

                      {/* HIGHLY POLISHED EXERCISE GRID */}
                      <div className="grid grid-cols-3 gap-2 mt-3">
                        {getPostExercises(post).map((ex, idx) => (
                          <div
                            key={"home-feed-ex-" + idx}
                            className="flex flex-col items-center bg-bg-surface-hover/60 border border-border rounded-xl p-2 hover:bg-bg-surface-hover transition-all group/item"
                          >
                            <div className="w-10 h-10 rounded-lg bg-bg-surface flex items-center justify-center overflow-hidden mb-1 border border-border relative">
                              {ex.imageUrl ? (
                                <img
                                  src={ex.imageUrl}
                                  alt={ex.exerciseName}
                                  className="w-full h-full object-cover transition-transform duration-300 group-hover/item:scale-110"
                                  referrerPolicy="no-referrer"
                                  onError={(e) => {
                                    e.currentTarget.style.display = "none";
                                  }}
                                />
                              ) : (
                                <Dumbbell className="w-4 h-4 text-text-muted animate-pulse" />
                              )}
                            </div>
                            <span className="text-[9px] font-black text-primary leading-tight">
                              {ex.setsCount} {isAr ? "مجاميع" : "Sets"}
                            </span>
                            <span className="text-[8px] text-text-secondary font-bold truncate w-full text-center px-0.5 capitalize leading-tight mt-0.5">
                              {ex.exerciseName}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Likes/Kudos Section */}
                    <div className="flex items-center justify-between border-t border-border/40 pt-2">
                      <button
                        onClick={() => giveKudos(post.id)}
                        className="flex items-center gap-2 text-text-muted hover:text-primary transition-colors hover:scale-105 active:scale-95 group"
                      >
                        <Heart className="w-4 h-4 group-hover:fill-primary text-primary" />
                        <span className="text-xs font-black font-mono">
                          {post.kudosCount} {t.kudos}
                        </span>
                      </button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            )}
          </div>
        )}
      </motion.div>

      {/* ── Quick Links ── */}
      <motion.div
        className="grid grid-cols-2 gap-3 pb-8"
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={6}
      >
        <Link
          to="/stats"
          className="glass-card flex flex-col items-center gap-3 rounded-[--radius-card] p-4 transition-colors hover:bg-bg-elevated"
        >
          <TrendingUp className="h-6 w-6 text-success" />
          <span className="text-sm font-bold text-text-primary tracking-wide">
            {t.statistics}
          </span>
        </Link>
        <Link
          to="/body"
          className="glass-card flex flex-col items-center gap-3 rounded-[--radius-card] p-4 transition-colors hover:bg-bg-elevated"
        >
          <Target className="h-6 w-6 text-warning" />
          <span className="text-sm font-bold text-text-primary tracking-wide">
            {t.bodyMetrics}
          </span>
        </Link>
      </motion.div>
    </div>
  );
}
