import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  AreaChart,
  Area,
} from "recharts";
import {
  Trophy,
  Flame,
  Dumbbell,
  TrendingUp,
  Calendar,
  Clock,
  ChevronDown,
  Activity,
  Plus,
  Trash2,
  Edit2,
  Target,
  Award,
  CheckCircle2,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  X,
  Camera,
  Scale,
  Ruler,
  Image as ImageIcon,
  ChevronsLeftRight,
  Users,
  Heart,
  ArrowRight,
} from "lucide-react";
import { DataEmptyState } from "@/components/ui/DataEmptyState";
import { Button } from "@/components/ui/Button";
import { cn } from "@/utils/cn";
import { uid } from "@/utils/id";
import { Link, useNavigate } from "@tanstack/react-router";
import {
  getWorkoutStreak,
  getPersonalRecords,
  getWeeklyVolume,
  getWeeklyTonnage,
  getExerciseProgress,
  getEstimated1RM,
  getTotalStats,
  getMuscleGroupStats,
  getWorkoutDensity,
  getWeeklySetVolume,
  db,
  type BodyMeasurement,
  type ProgressPhoto,
} from "@/db";
import { useExerciseStore } from "@/store/useExerciseStore";
import { useSettingsStore } from "@/store/useSettingsStore";
import ExerciseProgressChart from "@/components/stats/ExerciseProgressChart";
import AnatomyModel from "@/components/stats/AnatomyModel";
import { WorkoutHeatmap } from "@/components/stats/WorkoutHeatmap";
import { PRProgressChart } from "@/components/stats/PRProgressChart";
import { WeightGoalTracker } from "@/components/stats/WeightGoalTracker";
import { WeeklyVolumeTarget } from "@/components/stats/WeeklyVolumeTarget";
import WorkoutHistoryList from "@/components/workout/WorkoutHistoryList";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.4, ease: "easeOut" as const },
  }),
};

// Weekly helper
function getStartAndEndOfWeek() {
  const now = new Date();
  const day = now.getDay();
  const diff = now.getDate() - day + (day === 0 ? -6 : 1); // Adjust for Sunday
  const start = new Date(now.setDate(diff));
  start.setHours(0, 0, 0, 0);

  const end = new Date(start);
  end.setDate(end.getDate() + 6);
  end.setHours(23, 59, 59, 999);

  return { start, end };
}

interface WorkoutGoal {
  id: string;
  type: "weekly_workouts" | "monthly_volume" | "weekly_time" | "exercise_1rm";
  target: number;
  exerciseId?: string | number;
  exerciseName?: string;
  createdAt: string;
}

const DEFAULT_GOALS: WorkoutGoal[] = [
  {
    id: "default-1",
    type: "weekly_workouts",
    target: 3,
    createdAt: new Date().toISOString(),
  },
  {
    id: "default-2",
    type: "monthly_volume",
    target: 15000,
    createdAt: new Date().toISOString(),
  },
];

const monthsEn = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const monthsAr = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
];

export default function StatsPage() {
  const navigate = useNavigate();
  const { exercises, loadExercises } = useExerciseStore();
  const { language } = useSettingsStore();
  const isAr = language === "ar";

  // Sub-tab Navigation matching the video's top tab bar:
  // "نظرة سريعة" | "تمرينات" | "القياسات" | "صور"
  const [activeTab, setActiveTab] = useState<"overview" | "exercises" | "measurements" | "photos" | "history">("overview");

  // ── Tab 1: Overview States ──
  const [streak, setStreak] = useState(0);
  const [totalStats, setTotalStats] = useState({
    totalWorkouts: 0,
    totalVolume: 0,
    totalDuration: 0,
  });
  const [personalRecords, setPersonalRecords] = useState<any[]>([]);
  const [weeklyVolume, setWeeklyVolume] = useState<{ week: string; volume: number }[]>([]);
  const [weeklyTonnage, setWeeklyTonnage] = useState<{ week: string; tonnage: number }[]>([]);
  const [muscleGroupStats, setMuscleGroupStats] = useState<{ muscle: string; volume: number }[]>([]);
  const [e1rms, setE1rms] = useState<{ exerciseName: string; e1rm: number }[]>([]);
  const [sessionsList, setSessionsList] = useState<any[]>([]);
  const [muscleRecovery, setMuscleRecovery] = useState<Record<string, { percent: number; hoursLeft: number }>>({});
  const [workedThisWeek, setWorkedThisWeek] = useState<Record<string, number>>({});
  const [isRecoveryModalOpen, setIsRecoveryModalOpen] = useState(false);

  // Sparkline Trends data
  const [workoutSparkline, setWorkoutSparkline] = useState<{ value: number }[]>([]);
  const [volumeSparkline, setVolumeSparkline] = useState<{ value: number }[]>([]);
  const [durationSparkline, setDurationSparkline] = useState<{ value: number }[]>([]);
  const [carouselIndex, setCarouselIndex] = useState(0);

  // ── Tab 3: Measurements States ──
  const [measurements, setMeasurements] = useState<BodyMeasurement[]>([]);
  const [showAddMeasurement, setShowAddMeasurement] = useState(false);
  const [measurementForm, setMeasurementForm] = useState({
    weight: "",
    bodyFat: "",
    waist: "",
    chest: "",
  });

  // ── Tab 4: Photos States ──
  const [photos, setPhotos] = useState<(ProgressPhoto & { url: string })[]>([]);
  const [sliderPos, setSliderPos] = useState(50);
  const [beforePhotoId, setBeforePhotoId] = useState<string>("");
  const [afterPhotoId, setAfterPhotoId] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // ── Workout Goals States ──
  const [goals, setGoals] = useState<WorkoutGoal[]>([]);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [editingGoal, setEditingGoal] = useState<WorkoutGoal | null>(null);
  const [goalType, setGoalType] = useState<WorkoutGoal["type"]>("weekly_workouts");
  const [goalTarget, setGoalTarget] = useState("");
  const [goalExerciseId, setGoalExerciseId] = useState("");

  const [workoutDensity, setWorkoutDensity] = useState<{ date: string; count: number }[]>([]);
  const [weeklySetVolume, setWeeklySetVolume] = useState<{ muscle: string; sets: number }[]>([]);
  const [selectedPrId, setSelectedPrId] = useState<string | number | null>(null);
  const [prHistory, setPrHistory] = useState<any[]>([]);

  // Translate helper
  const t = {
    overview: isAr ? "نظرة سريعة" : "Overview",
    exercises: isAr ? "تمرينات" : "Exercises",
    measurements: isAr ? "القياسات" : "Measurements",
    photos: isAr ? "صور" : "Photos",
    streak: isAr ? "الاستمرارية 🔥" : "Commitment Streak 🔥",
    workouts: isAr ? "تمرينات" : "Workouts",
    volume: isAr ? "التوتال (حجم التمرين)" : "Training Volume",
    duration: isAr ? "الوقت" : "Duration",
    ton: isAr ? "طن" : "Ton",
    kg: isAr ? "كجم" : "Kg",
    days: isAr ? "أيام" : "Days",
    mins: isAr ? "دقيقة" : "mins",
    compared3Months: isAr ? "مقارنة بآخر ٣ شهور" : "Compared to last 3 months",
    totalEffort: isAr ? "الوقت الكلي للتمرين" : "Total effort time logged",
    muscleRecoveryTitle: isAr ? "استشفاء العضلات" : "Muscle Recovery",
    anyReadyToTrain: isAr ? "شوف إيه العضلات اللي جاهزة تتفرم" : "See which muscles are ready to train",
    viewAll: isAr ? "شوف كله" : "View All",
    readyToLift: isAr ? "جاهزة للدمار" : "READY TO LIFT",
    hoursRemaining: (h: number) => isAr ? `متبقي ${h} ساعة` : `${h}h remaining`,
    thisWeek: isAr ? "هذا الأسبوع" : "This Week",
    focusWhereThisWeek: isAr ? "تعرّف على عضلات تمرينك" : "See where you focused your workouts this week",
    suggestedGoal: isAr ? "هدفك الأسبوع ده" : "Suggested Goal",
    workoutsPerWeek: (n: number) => isAr ? `${n} تدريبات أسبوعياً` : `${n} workouts weekly`,
    completed: isAr ? "خلصتها" : "completed",
    setGoal: isAr ? "ظبط الهدف" : "Change Goal",
    thisMonthFocus: isAr ? "الشهر ده" : "This Month",
    whereFocusedMore: isAr ? "شوف ركزت على إيه أكتر" : "See where you focused more",
    exerciseLog: isAr ? "سجل التمارين" : "Exercise Log",
    personalRecordsTitle: isAr ? "أرقامك القياسية" : "Personal Records",
    prsDesc: isAr ? "شوف أعلى أوزان شلتها وتطورك" : "Track your strongest lifts over time",
    addFriendsTitle: isAr ? "شجع صحابك واتشجعوا!" : "Double your gains, double the fun!",
    addFriendsDesc: isAr ? "شير فورمتك مع أصحابك وادعموا بعض في الجيم." : "Inspire friends with your fitness journey and support each other.",
    addFriendsBtn: isAr ? "ضيف أصحابك" : "Add Friends",
    avgRecovery: isAr ? "متوسط استشفاء العضلات حسب تمرينات آخر ٧ أيام" : "Average recovery for all muscles based on training over the last 7 days",
    muscleStatusLabel: isAr ? "حالة العضلة والوقت عشان ترتاح" : "Muscle status & recovery countdown",
    addWeightLog: isAr ? "سجل وزن ومقاسات جديدة ⚖️" : "Log New Weight & Metrics ⚖️",
    weightLabel: isAr ? "الوزن (كجم)" : "Weight (kg)",
    fatLabel: isAr ? "نسبة الدهون (%)" : "Body Fat (%)",
    waistLabel: isAr ? "محيط الوسط (سم)" : "Waist (cm)",
    chestLabel: isAr ? "محيط الصدر (سم)" : "Chest (cm)",
    saveBtn: isAr ? "حفظ" : "إحفظ",
    cancelBtn: isAr ? "إلغاء" : "Cancel",
    beforeAfterTitle: isAr ? "مقارنة الصور ⚡" : "Interactive Before & After ⚡",
    uploadPhotoBtn: isAr ? "ارفع صورة لتطورك" : "Upload New Progress Photo",
    photoHistoryTitle: isAr ? "صورك القديمة" : "Photo History",
  };

  const getMuscleLabel = (muscle: string) => {
    if (!isAr) return muscle;
    const map: { [key: string]: string } = {
      Chest: "الصدر",
      Back: "الظهر",
      Legs: "الأرجل",
      Shoulders: "الأكتاف",
      Arms: "الذراعين",
      Core: "البطن"
    };
    return map[muscle] || muscle;
  };

  useEffect(() => {
    loadExercises();
  }, [loadExercises]);

  // Load all overview statistics & calculate muscle recovery / week history
  useEffect(() => {
    async function loadData() {
      const [
        streakData,
        statsData,
        prsData,
        volumeData,
        tonnageData,
        muscleData,
        densityData,
        setVolumeData,
        allSessions,
      ] = await Promise.all([
        getWorkoutStreak(),
        getTotalStats(),
        getPersonalRecords(),
        getWeeklyVolume(10),
        getWeeklyTonnage(10),
        getMuscleGroupStats(exercises),
        getWorkoutDensity(),
        getWeeklySetVolume(exercises),
        db.workoutSessions.where("completed").equals(1).toArray(),
      ]);

      setStreak(streakData);
      setTotalStats(statsData);
      setPersonalRecords(prsData);
      setWeeklyVolume(volumeData);
      setWeeklyTonnage(tonnageData);
      setMuscleGroupStats(muscleData);
      setWorkoutDensity(densityData);
      setWeeklySetVolume(setVolumeData);
      setSessionsList(allSessions);

      // Helper for week keys
      const getWKey = (d: Date) => {
        const startOfYear = new Date(d.getFullYear(), 0, 1);
        const days = Math.floor((d.getTime() - startOfYear.getTime()) / 86400000);
        const weekNum = Math.ceil((days + startOfYear.getDay() + 1) / 7);
        return `W${weekNum}`;
      };

      // Generate sparklines trends directly from actual workout sessions
      const workoutTrend = volumeData.map((v) => {
        const count = allSessions.filter((s) => getWKey(new Date(s.date)) === v.week).length;
        return { value: count };
      });
      const volumeTrend = volumeData.map((v) => ({ value: v.volume || 0 }));
      const durationTrend = volumeData.map((v) => {
        const totalSecs = allSessions
          .filter((s) => getWKey(new Date(s.date)) === v.week)
          .reduce((acc, s) => acc + (s.duration || 0), 0);
        return { value: Math.round(totalSecs / 60) };
      });

      setWorkoutSparkline(workoutTrend.length > 0 ? workoutTrend : [{ value: 0 }, { value: 0 }, { value: 0 }]);
      setVolumeSparkline(volumeTrend.length > 0 ? volumeTrend : [{ value: 0 }, { value: 0 }, { value: 0 }]);
      setDurationSparkline(durationTrend.length > 0 ? durationTrend : [{ value: 0 }, { value: 0 }, { value: 0 }]);

      // Muscle Recovery & Workouts This Week calculation
      const MUSCLE_GROUPS = ["Chest", "Back", "Legs", "Shoulders", "Arms", "Core"];
      const recoveryMap: Record<string, { percent: number; hoursLeft: number }> = {};
      const weeklyWorkedMap: Record<string, number> = {};

      const nowTime = Date.now();
      const oneWeekAgo = nowTime - 7 * 24 * 3600000;

      // Helper to map exercise data to major categories
      const getCategory = (ex: any): string => {
        const mGroup = (ex.muscleGroup || "").toLowerCase();
        const target = (ex.target || "").toLowerCase();
        const exName = (ex.exerciseName || "").toLowerCase();
        const combined = mGroup + " " + target + " " + exName;
        
        if (combined.includes("chest") || combined.includes("pectoral") || combined.includes("bench")) return "Chest";
        if (combined.includes("back") || combined.includes("lat") || combined.includes("trap") || combined.includes("row") || combined.includes("pullup")) return "Back";
        if (combined.includes("quad") || combined.includes("ham") || combined.includes("glute") || combined.includes("leg") || combined.includes("squat") || combined.includes("calf")) return "Legs";
        if (combined.includes("delt") || combined.includes("shoulder") || combined.includes("press")) return "Shoulders";
        if (combined.includes("biceps") || combined.includes("triceps") || combined.includes("arm") || combined.includes("curl")) return "Arms";
        if (combined.includes("abs") || combined.includes("core") || combined.includes("oblique") || combined.includes("crunch")) return "Core";
        return "";
      };

      for (const muscle of MUSCLE_GROUPS) {
        // Find latest session for this muscle category
        const relevantSessions = allSessions.filter((s) => {
          return s.exercises.some((ex) => {
            const def = exercises.find((e) => String(e.id) === String(ex.exerciseId));
            const cat = getCategory(ex) || (def ? getCategory(def) : "");
            return cat === muscle;
          });
        });

        const latestSession = relevantSessions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

        if (!latestSession) {
          recoveryMap[muscle] = { percent: 100, hoursLeft: 0 };
        } else {
          const hoursElapsed = (nowTime - new Date(latestSession.date).getTime()) / 3600000;
          const hoursLeft = Math.max(0, 48 - hoursElapsed);
          const percent = Math.min(100, Math.round((hoursElapsed / 48) * 100));
          recoveryMap[muscle] = { percent, hoursLeft: Math.round(hoursLeft * 10) / 10 };
        }

        // Check if worked this week
        const workedThisWeekSessions = relevantSessions.filter((s) => new Date(s.date).getTime() >= oneWeekAgo);
        weeklyWorkedMap[muscle] = workedThisWeekSessions.length > 0 ? 100 : 0;
      }

      setMuscleRecovery(recoveryMap);
      setWorkedThisWeek(weeklyWorkedMap);

      // Top 1RMs
      const calculated1RMs = await Promise.all(
        prsData.slice(0, 4).map(async (pr) => {
          const e1rmData = await getEstimated1RM(pr.exerciseId);
          const best = e1rmData.length > 0 ? Math.max(...e1rmData.map((d) => d.e1rm)) : 0;
          return {
            exerciseName: pr.exerciseName,
            e1rm: best,
          };
        }),
      );
      setE1rms(calculated1RMs.filter((item) => item.e1rm > 0));
    }

    loadData();
  }, [exercises]);

  // Load Measurements and Photos
  useEffect(() => {
    loadMeasurementsAndPhotos();
  }, []);

  async function loadMeasurementsAndPhotos() {
    const [measurementsData, photosData] = await Promise.all([
      db.bodyMeasurements.orderBy("date").reverse().toArray(),
      db.progressPhotos.orderBy("date").reverse().toArray(),
    ]);

    setMeasurements(measurementsData);

    const photosWithUrls = photosData.map((photo) => ({
      ...photo,
      url: URL.createObjectURL(photo.imageBlob),
    }));
    setPhotos(photosWithUrls);

    if (photosWithUrls.length >= 2) {
      setBeforePhotoId(photosWithUrls[photosWithUrls.length - 1].id || "");
      setAfterPhotoId(photosWithUrls[0].id || "");
    }
  }

  // Goal Progress Calculator
  const getGoalProgress = (goal: WorkoutGoal) => {
    if (goal.type === "weekly_workouts") {
      const { start, end } = getStartAndEndOfWeek();
      return sessionsList.filter((s) => {
        const d = new Date(s.date);
        return d >= start && d <= end;
      }).length;
    }
    if (goal.type === "monthly_volume") {
      const now = new Date();
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);

      let vol = 0;
      sessionsList
        .filter((s) => {
          const d = new Date(s.date);
          return d >= start && d <= end;
        })
        .forEach((s) => {
          s.exercises.forEach((ex: any) => {
            ex.sets.forEach((set: any) => {
              if (set.completed) {
                vol += (Number(set.weight) || 0) * (Number(set.reps) || 0);
              }
            });
          });
        });
      return vol;
    }
    return 0;
  };

  // Submit new measurement
  const handleAddMeasurementSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!measurementForm.weight) return;

    const measurement: BodyMeasurement = {
      id: uid(),
      date: new Date().toISOString(),
      weight: Number(measurementForm.weight),
      bodyFat: measurementForm.bodyFat ? Number(measurementForm.bodyFat) : undefined,
      waist: measurementForm.waist ? Number(measurementForm.waist) : undefined,
      chest: measurementForm.chest ? Number(measurementForm.chest) : undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await db.bodyMeasurements.add(measurement);
    setMeasurementForm({ weight: "", bodyFat: "", waist: "", chest: "" });
    setShowAddMeasurement(false);
    loadMeasurementsAndPhotos();
  };

  // Photo uploads
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const photo: ProgressPhoto = {
      id: uid(),
      date: new Date().toISOString(),
      type: "front",
      imageBlob: file,
      createdAt: new Date().toISOString(),
    };

    await db.progressPhotos.add(photo);
    loadMeasurementsAndPhotos();
  };

  const deletePhoto = async (id: string) => {
    if (!confirm(isAr ? "متأكد إنك عايز تمسح الصورة دي؟" : "Are you sure you want to delete this photo?")) return;
    await db.progressPhotos.delete(id);
    loadMeasurementsAndPhotos();
  };

  // Goals load/save
  useEffect(() => {
    const stored = localStorage.getItem("pulse_workout_goals");
    if (stored) {
      try {
        setGoals(JSON.parse(stored));
      } catch (e) {
        setGoals(DEFAULT_GOALS);
      }
    } else {
      localStorage.setItem("pulse_workout_goals", JSON.stringify(DEFAULT_GOALS));
      setGoals(DEFAULT_GOALS);
    }
  }, []);

  const saveGoals = (newGoals: WorkoutGoal[]) => {
    setGoals(newGoals);
    localStorage.setItem("pulse_workout_goals", JSON.stringify(newGoals));
  };

  const handleSaveGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalTarget || isNaN(Number(goalTarget))) return;

    const newGoal: WorkoutGoal = {
      id: uid(),
      type: goalType,
      target: Number(goalTarget),
      createdAt: new Date().toISOString(),
    };
    saveGoals([...goals, newGoal]);
    setShowGoalModal(false);
  };

  // Calendar Heatmap Strip Calculations
  const getWeeklyCalendarStrip = () => {
    const strip = [];
    const now = new Date();
    // Start from 6 days ago up to today
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(now.getDate() - i);
      const isSessionLogged = sessionsList.some((s) => {
        const sd = new Date(s.date);
        return sd.getDate() === d.getDate() && sd.getMonth() === d.getMonth() && sd.getFullYear() === d.getFullYear();
      });
      strip.push({
        dateNum: d.getDate(),
        dayLabel: d.toLocaleDateString(isAr ? "ar-EG" : "en-US", { weekday: "narrow" }),
        active: isSessionLogged,
        isToday: i === 0,
      });
    }
    return strip;
  };

  const calendarStrip = getWeeklyCalendarStrip();

  // Selected comparison photos mapping
  const beforePhoto = photos.find((p) => p.id === beforePhotoId);
  const afterPhoto = photos.find((p) => p.id === afterPhotoId);

  return (
    <div className="space-y-6 pb-20 pt-2 animate-fade-in" dir={isAr ? "rtl" : "ltr"}>
      {/* ── Top Premium Viewport Sub-Tabs Navigation ── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b border-border/40 pb-3">
        <div className="flex items-center gap-1.5 p-1 bg-bg-surface/80 backdrop-blur-md rounded-2xl border border-border/50 overflow-x-auto no-scrollbar shadow-inner">
          {[
            { id: "overview", label: t.overview, icon: Activity },
            { id: "history", label: isAr ? "السجل ⏱️" : "History ⏱️", icon: Clock },
            { id: "exercises", label: t.exercises, icon: Dumbbell },
            { id: "measurements", label: t.measurements, icon: Scale },
            { id: "photos", label: t.photos, icon: Camera },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  if (typeof navigator !== "undefined" && navigator.vibrate) {
                    navigator.vibrate(10);
                  }
                }}
                className={cn(
                  "relative flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer shrink-0 select-none",
                  isActive
                    ? "text-primary-text font-black"
                    : "text-text-muted hover:text-text-primary hover:bg-bg-surface-hover/50"
                )}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeSubTabPill"
                    className="absolute inset-0 bg-primary rounded-xl shadow-[0_0_15px_rgba(204,255,0,0.4)]"
                    transition={{ type: "spring", stiffness: 400, damping: 28 }}
                  />
                )}
                <span className="relative z-10 flex items-center gap-1.5">
                  <Icon size={14} strokeWidth={isActive ? 2.5 : 2} />
                  <span>{tab.label}</span>
                </span>
              </button>
            );
          })}
        </div>
        <div className="hidden sm:flex items-center gap-2">
          <span className="text-[10px] text-primary font-extrabold uppercase tracking-widest bg-primary/10 border border-primary/20 px-2.5 py-1 rounded-full shadow-sm">
            ⚡ ANALYTICS PRO
          </span>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {/* ── TAB 1: OVERVIEW TAB ── */}
        {activeTab === "overview" && (
          <motion.div
            key="overview-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            {/* Consistency Heatmap */}
            <motion.div
              className="rounded-[--radius-card] glass-card p-5"
              variants={fadeUp}
              initial="hidden"
              animate="visible"
              custom={0.2}
            >
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-text-primary uppercase tracking-wider">
                    {isAr ? "نشاط التدريب" : "Training Activity"}
                  </h2>
                  <p className="text-[10px] text-text-muted uppercase tracking-wider font-medium">
                    {isAr ? "الاستمرارية في آخر ١٢ أسبوع" : "Consistency over last 12 weeks"}
                  </p>
                </div>
                <Activity className="h-5 w-5 text-primary" />
              </div>
              <WorkoutHeatmap data={workoutDensity} isAr={isAr} />
            </motion.div>

            {/* Advanced Weekly Volume Tracking */}
            <motion.div
              className="rounded-[--radius-card] glass-card p-5 border border-border/50"
              variants={fadeUp}
              initial="hidden"
              animate="visible"
              custom={0.25}
            >
              <WeeklyVolumeTarget data={weeklySetVolume} isAr={isAr} />
            </motion.div>

            {/* ── Horizontally Scrollable KPI Sparkline Carousel ── */}
            <div className="relative group overflow-hidden">
              <div className="flex gap-4 overflow-x-auto snap-x snap-mandatory no-scrollbar scroll-smooth" id="metric-carousel">
                {/* Workouts Slide */}
                <div className="w-full shrink-0 snap-start snap-always bg-gradient-to-b from-bg-surface to-bg-surface-hover border border-border rounded-[--radius-card] p-5 relative overflow-hidden flex flex-col justify-between h-44">
                  <div>
                    <div className="flex justify-between items-start">
                      <span className="text-xs text-text-secondary font-bold uppercase tracking-wider">
                        {isAr ? "التمارين" : "Workouts Completed"}
                      </span>
                      <span className="text-[9px] text-text-muted font-mono font-bold">
                        {t.compared3Months}
                      </span>
                    </div>
                    <div className="flex items-baseline gap-1.5 mt-2">
                      <span className="text-3xl font-black text-text-primary tabular-nums">
                        {totalStats.totalWorkouts}
                      </span>
                      <span className="text-xs text-text-muted font-bold uppercase tracking-wider">
                        {isAr ? "تمرينات" : "Sessions"}
                      </span>
                    </div>
                  </div>
                  {/* Miniature Sparkline */}
                  <div className="h-16 w-full -mx-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={workoutSparkline}>
                        <defs>
                          <linearGradient id="workoutGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#CCFF00" stopOpacity={0.2}/>
                            <stop offset="95%" stopColor="#CCFF00" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <Area type="monotone" dataKey="value" stroke="#CCFF00" strokeWidth={1.5} fillOpacity={1} fill="url(#workoutGrad)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Training Volume Slide */}
                <div className="w-full shrink-0 snap-start snap-always bg-gradient-to-b from-bg-surface to-bg-surface-hover border border-border rounded-[--radius-card] p-5 relative overflow-hidden flex flex-col justify-between h-44">
                  <div>
                    <div className="flex justify-between items-start">
                      <span className="text-xs text-text-secondary font-bold uppercase tracking-wider">
                        {t.volume}
                      </span>
                      <span className="text-[9px] text-text-muted font-mono font-bold">
                        {isAr ? "كجم توتال" : "Total Tonnage"}
                      </span>
                    </div>
                    <div className="flex items-baseline gap-1.5 mt-2">
                      <span className="text-3xl font-black text-text-primary tabular-nums">
                        {totalStats.totalVolume >= 1000 ? (totalStats.totalVolume / 1000).toFixed(1) : totalStats.totalVolume}
                      </span>
                      <span className="text-xs text-text-muted font-bold uppercase tracking-wider">
                        {totalStats.totalVolume >= 1000 ? t.ton : t.kg}
                      </span>
                    </div>
                  </div>
                  {/* Sparkline */}
                  <div className="h-16 w-full -mx-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={volumeSparkline}>
                        <defs>
                          <linearGradient id="volGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#22C55E" stopOpacity={0.2}/>
                            <stop offset="95%" stopColor="#22C55E" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <Area type="monotone" dataKey="value" stroke="#22C55E" strokeWidth={1.5} fillOpacity={1} fill="url(#volGrad)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Duration Slide */}
                <div className="w-full shrink-0 snap-start snap-always bg-gradient-to-b from-bg-surface to-bg-surface-hover border border-border rounded-[--radius-card] p-5 relative overflow-hidden flex flex-col justify-between h-44">
                  <div>
                    <div className="flex justify-between items-start">
                      <span className="text-xs text-text-secondary font-bold uppercase tracking-wider">
                        {t.duration}
                      </span>
                      <span className="text-[9px] text-text-muted font-mono font-bold">
                        {t.totalEffort}
                      </span>
                    </div>
                    <div className="flex items-baseline gap-1.5 mt-2">
                      <span className="text-3xl font-black text-text-primary tabular-nums">
                        {Math.round(totalStats.totalDuration / 60)}
                      </span>
                      <span className="text-xs text-text-muted font-bold uppercase tracking-wider">
                        {isAr ? "ساعة" : "hours"}
                      </span>
                    </div>
                  </div>
                  {/* Sparkline */}
                  <div className="h-16 w-full -mx-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={durationSparkline}>
                        <defs>
                          <linearGradient id="durGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#06B6D4" stopOpacity={0.2}/>
                            <stop offset="95%" stopColor="#06B6D4" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <Area type="monotone" dataKey="value" stroke="#06B6D4" strokeWidth={1.5} fillOpacity={1} fill="url(#durGrad)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Slider indicators matching the video's three-dot list */}
              <div className="flex justify-center gap-1.5 mt-3">
                {[0, 1, 2].map((idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setCarouselIndex(idx);
                      const el = document.getElementById("metric-carousel");
                      if (el) {
                        const width = el.clientWidth;
                        el.scrollTo({ left: width * idx, behavior: "smooth" });
                      }
                    }}
                    className={cn(
                      "h-1.5 rounded-full transition-all duration-300",
                      carouselIndex === idx ? "w-4 bg-primary" : "w-1.5 bg-bg-surface-hover"
                    )}
                  />
                ))}
              </div>
            </div>

            {/* ── Muscle Recovery Tracker Bento Widget ── */}
            <div className="glass-card rounded-[--radius-card] p-5 border border-border space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
                    {t.muscleRecoveryTitle} 🩺
                  </h3>
                  <p className="text-[10px] text-text-muted font-bold">
                    {t.anyReadyToTrain}
                  </p>
                </div>
                <button
                  onClick={() => setIsRecoveryModalOpen(true)}
                  className="text-xs font-black text-primary hover:text-primary-hover uppercase tracking-wider"
                >
                  {t.viewAll}
                </button>
              </div>

              <div className="flex gap-3 overflow-x-auto no-scrollbar py-1">
                {Object.entries(muscleRecovery).map(([muscle, stats]) => {
                  const isFresh = stats.percent === 100;
                  const isSore = stats.percent < 40;

                  let colorClass = "bg-primary";
                  let textClass = "text-primary";
                  let borderClass = "border-primary/20";
                  if (isSore) {
                    colorClass = "bg-red-500";
                    textClass = "text-red-400";
                    borderClass = "border-red-500/20";
                  } else if (stats.percent < 100) {
                    colorClass = "bg-yellow-500";
                    textClass = "text-yellow-400";
                    borderClass = "border-yellow-500/20";
                  }

                  return (
                    <button
                      key={muscle}
                      onClick={() => setIsRecoveryModalOpen(true)}
                      className={cn(
                        "p-3 rounded-xl border bg-bg-surface-hover flex flex-col justify-between h-24 min-w-[110px] transition-all hover:bg-bg-elevated cursor-pointer shrink-0 text-right",
                        borderClass
                      )}
                    >
                      <div className="flex justify-between items-start w-full">
                        <span className="text-xs font-black text-text-primary uppercase tracking-wider">
                          {getMuscleLabel(muscle)}
                        </span>
                        <span className={cn("text-xs font-mono font-black", textClass)}>
                          {stats.percent}%
                        </span>
                      </div>

                      <div className="space-y-1 w-full">
                        <div className="h-1.5 w-full bg-bg-surface-hover rounded-full overflow-hidden">
                          <div className={cn("h-full rounded-full", colorClass)} style={{ width: `${stats.percent}%` }} />
                        </div>
                        <p className="text-[8px] text-text-muted font-bold uppercase tracking-wider font-mono truncate">
                          {isFresh ? t.readyToLift : t.hoursRemaining(stats.hoursLeft)}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ── "الأسبوع ده" (This Week) Anatomy & Calendar Streak ── */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="glass-card rounded-[--radius-card] p-5 border border-border space-y-4 flex flex-col justify-between">
                <div>
                  <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
                    {t.thisWeek} 📊
                  </h3>
                  <p className="text-[10px] text-text-muted font-bold">
                    {t.focusWhereThisWeek}
                  </p>
                </div>

                {/* 3D-like muscular vector mapping of active muscles this week */}
                <div className="py-2 flex flex-col items-center bg-bg-surface/20 rounded-2xl border border-border">
                  <AnatomyModel
                    muscleLevels={workedThisWeek}
                    view="both"
                    highlightColor="red"
                    isAr={isAr}
                  />
                  <button
                    onClick={() => {
                      document.getElementById("radar-focus")?.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="mt-2 text-[10px] font-black text-primary hover:text-primary-light uppercase tracking-wider flex items-center gap-1 transition-all cursor-pointer"
                  >
                    <span>{isAr ? "شاهد أين تركز هذا الأسبوع" : "See where you focused this week"}</span>
                    <span>➔</span>
                  </button>
                </div>

                {/* Calendar strip showing filled workout indicators */}
                <div className="flex justify-between bg-bg-surface p-2.5 rounded-xl border border-border mt-2">
                  {calendarStrip.map((day, idx) => (
                    <div key={idx} className="flex flex-col items-center gap-1.5">
                      <span className="text-[9px] text-text-muted font-bold uppercase">
                        {day.dayLabel}
                      </span>
                      <div
                        className={cn(
                          "w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-black transition-all relative",
                          day.active
                            ? "bg-primary border-primary text-primary-text shadow-md shadow-primary/20 scale-105 font-black"
                            : day.isToday
                            ? "bg-bg-surface-hover border border-border text-text-primary"
                            : "bg-bg-surface-hover text-text-muted border border-border"
                        )}
                      >
                        {day.dateNum}
                        {day.active && (
                          <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-bg-surface rounded-full border border-primary" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* ── Suggested Goal Widget ── */}
              {goals.map((goal) => {
                if (goal.type !== "weekly_workouts") return null;
                const progress = getGoalProgress(goal);
                const percent = Math.min(Math.round((progress / goal.target) * 100), 100);
                // SVG circular parameters
                const radius = 32;
                const circumference = 2 * Math.PI * radius;
                const offset = circumference - (percent / 100) * circumference;

                return (
                  <div key={goal.id} className="glass-card rounded-[--radius-card] p-5 border border-border flex flex-col justify-between">
                    <div>
                      <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
                        {t.suggestedGoal} 🏆
                      </h3>
                      <p className="text-xs text-text-secondary font-bold mt-2">
                        {t.workoutsPerWeek(goal.target)}
                      </p>
                    </div>

                    <div className="flex items-center justify-between my-4">
                      <div className="flex items-center gap-3">
                        <div className="relative w-20 h-20 flex items-center justify-center">
                          <svg className="w-full h-full transform -rotate-90">
                            <circle
                              cx="40"
                              cy="40"
                              r={radius}
                              stroke="#1E1E24"
                              strokeWidth="6"
                              fill="transparent"
                            />
                            <motion.circle
                              cx="40"
                              cy="40"
                              r={radius}
                              stroke="#CCFF00"
                              strokeWidth="6"
                              fill="transparent"
                              strokeDasharray={circumference}
                              initial={{ strokeDashoffset: circumference }}
                              animate={{ strokeDashoffset: offset }}
                              transition={{ duration: 1, ease: "easeOut" }}
                            />
                          </svg>
                          <div className="absolute inset-0 flex flex-col items-center justify-center font-black">
                            <span className="text-base text-text-primary font-mono">{percent}%</span>
                          </div>
                        </div>
                        <div>
                          <p className="text-xs text-text-muted font-bold">
                            {isAr ? "تم إكمال" : "Completed"}
                          </p>
                          <p className="text-xl font-black text-text-primary font-mono">
                            {progress} / {goal.target}
                          </p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setActiveTab("exercises")}
                      >
                        {t.setGoal}
                      </Button>
                    </div>

                    <p className="text-[10px] text-text-muted font-semibold uppercase leading-relaxed">
                      {isAr
                        ? "استمر في التقدم لتحقيق رصيدك الأسبوعي وتثبيت روتين لياقتك!"
                        : "Keep moving to hit your weekly streak and solidifying your gym routine!"}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* ── This Month Focus Radar Chart ── */}
            <div id="radar-focus" className="glass-card rounded-[--radius-card] p-5 border border-border space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
                    {t.thisMonthFocus} 🎯
                  </h3>
                  <p className="text-[10px] text-text-muted font-bold">
                    {t.whereFocusedMore}
                  </p>
                </div>
              </div>

              {muscleGroupStats.length > 0 ? (
                <div className="h-64 flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart cx="50%" cy="50%" outerRadius="75%" data={muscleGroupStats}>
                      <PolarGrid stroke="#27272A" />
                      <PolarAngleAxis
                        dataKey="muscle"
                        tick={{ fill: "#A1A1AA", fontSize: 10, textAnchor: "middle" }}
                      />
                      <PolarRadiusAxis angle={30} domain={[0, "auto"]} tick={false} axisLine={false} />
                      <Radar
                        name="Volume"
                        dataKey="volume"
                        stroke="#CCFF00"
                        fill="#CCFF00"
                        fillOpacity={0.35}
                        animationDuration={1000}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1C1C1F",
                          border: "1px solid #27272A",
                          borderRadius: 8,
                          fontSize: 12,
                        }}
                        labelStyle={{ color: "#F5F5F7" }}
                        formatter={(value) => [`${Number(value).toLocaleString()} kg`, "Volume"]}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <DataEmptyState
                  icon={Activity}
                  title="No Data Yet"
                  description="Log some workouts to see muscle focus radar chart."
                />
              )}
            </div>

            {/* ── Exercise Log Trends (Bar Chart) ── */}
            <div className="glass-card rounded-[--radius-card] p-5 border border-border space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
                  {t.exerciseLog} 📈
                </h3>
              </div>

              {weeklyTonnage.length > 0 && weeklyTonnage.some((w) => w.tonnage > 0) ? (
                <div className="h-48">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={weeklyTonnage} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272A" vertical={false} />
                      <XAxis
                        dataKey="week"
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: "#A1A1AA", fontSize: 9 }}
                      />
                      <YAxis
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: "#A1A1AA", fontSize: 10 }}
                        tickFormatter={(v) => (v >= 1000 ? `${v / 1000}k` : v)}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1C1C1F",
                          border: "1px solid #27272A",
                          borderRadius: 8,
                          fontSize: 12,
                        }}
                        labelStyle={{ color: "#F5F5F7" }}
                        formatter={(value) => [`${Number(value).toLocaleString()} kg`, "Tonnage"]}
                      />
                      <Bar dataKey="tonnage" fill="#CCFF00" radius={[4, 4, 0, 0]} animationDuration={800} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <DataEmptyState
                  icon={TrendingUp}
                  title="No Data Yet"
                  description="Log some workouts to see muscle focus."
                />
              )}
            </div>

            {/* ── Personal Records Feed (PRs) ── */}
            <div className="glass-card rounded-[--radius-card] p-5 border border-border space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
                    {t.personalRecordsTitle} 🏆
                  </h3>
                  <p className="text-[10px] text-text-muted font-bold">
                    {t.prsDesc}
                  </p>
                </div>
              </div>

              {personalRecords.length > 0 ? (
                <div className="space-y-3">
                  {personalRecords.slice(0, 5).map((pr, idx) => (
                    <button
                      key={String(pr.exerciseId)}
                      onClick={async () => {
                        if (selectedPrId === pr.exerciseId) {
                          setSelectedPrId(null);
                          return;
                        }
                        setSelectedPrId(pr.exerciseId);
                        const history = await getEstimated1RM(pr.exerciseId);
                        setPrHistory(history);
                      }}
                      className={cn(
                        "w-full text-left bg-bg-surface-hover/40 border border-border rounded-xl p-3 flex flex-col transition-all",
                        selectedPrId === pr.exerciseId ? "ring-2 ring-primary border-primary/30 bg-bg-surface-hover/80" : "hover:bg-bg-surface-hover/60"
                      )}
                    >
                      <div className="flex items-center justify-between w-full">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg bg-bg-surface flex items-center justify-center border border-border">
                            <Trophy className={cn("h-5 w-5 transition-colors", selectedPrId === pr.exerciseId ? "text-primary animate-bounce" : "text-warning animate-pulse")} />
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-black text-text-primary capitalize truncate">
                              {pr.exerciseName}
                            </p>
                            <p className="text-[10px] text-text-muted font-semibold font-mono">
                              {new Date(pr.date).toLocaleDateString(isAr ? 'ar-EG' : undefined, {
                                day: 'numeric',
                                month: 'short',
                                year: 'numeric'
                              })}
                            </p>
                          </div>
                        </div>

                        <div className="text-right flex items-center gap-2">
                          <p className="text-sm font-black text-warning tabular-nums whitespace-nowrap">
                            {pr.maxWeight}
                            <span className="text-[10px] text-text-muted font-bold ml-0.5 uppercase tracking-tighter">kg</span>
                          </p>
                          <ChevronDown className={cn("h-4 w-4 text-text-muted/50 transition-transform", selectedPrId === pr.exerciseId && "rotate-180")} />
                        </div>
                      </div>

                      <AnimatePresence>
                        {selectedPrId === pr.exerciseId && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="w-full overflow-hidden"
                          >
                            <div className="mt-4 pt-4 border-t border-border/50">
                              <PRProgressChart data={prHistory} isAr={isAr} />
                              <div className="mt-2 flex justify-between text-[10px] font-bold text-text-muted uppercase tracking-wider px-1">
                                <span>{isAr ? "تطور القوة (1RM التقريبي)" : "Estimated 1RM Progression"}</span>
                                <span className="text-primary">
                                  {prHistory.length > 0 ? Math.round(prHistory[prHistory.length - 1].e1rm) : 0} kg
                                </span>
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </button>
                  ))}
                </div>
              ) : (
                <DataEmptyState
                  icon={Trophy}
                  title="No Records Yet"
                  description="Start logging workout sets to see your legendary lifts here!"
                />
              )}
            </div>

            {/* ── Add Friends / Social Share widget matching video's cute character block ── */}
            <div className="glass-card rounded-[--radius-card] p-5 border border-border bg-gradient-to-r from-primary/10 to-transparent flex flex-col sm:flex-row items-center gap-5">
              <div className="relative flex shrink-0">
                <div className="w-12 h-12 rounded-full bg-cyan-400 flex items-center justify-center font-black text-white text-sm z-10 shadow-lg">
                  ⚡
                </div>
                <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center font-black text-primary-text text-sm -ml-4 shadow-lg border-2 border-border">
                  👥
                </div>
              </div>
              <div className="flex-1 text-center sm:text-right">
                <h4 className="text-sm font-black text-text-primary">
                  {t.addFriendsTitle}
                </h4>
                <p className="text-xs text-text-secondary mt-1">
                  {t.addFriendsDesc}
                </p>
              </div>
              <Button
                variant="primary"
                onClick={() => navigate({ to: "/feed" })}
              >
                {t.addFriendsBtn}
                <Users className="w-4 h-4 ml-1.5" />
              </Button>
            </div>
          </motion.div>
        )}

        {/* ── TAB 2: EXERCISES TAB ── */}
        {activeTab === "exercises" && (
          <motion.div
            key="exercises-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            <ExerciseProgressChart />

            {/* Top 1RM Progress list */}
            <div className="glass-card rounded-[--radius-card] p-5 border border-border space-y-4">
              <div className="flex items-center gap-2">
                <Dumbbell className="h-5 w-5 text-primary" />
                <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
                  Estimated 1RM Achievements
                </h3>
              </div>

              {e1rms.length > 0 ? (
                <div className="space-y-3">
                  {e1rms.map((pr) => (
                    <div
                      key={pr.exerciseName}
                      className="bg-bg-surface-hover border border-border rounded-xl p-3 flex items-center justify-between"
                    >
                      <span className="text-xs font-bold text-text-primary capitalize">{pr.exerciseName}</span>
                      <span className="text-sm font-black text-primary font-mono">{pr.e1rm} kg</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-text-muted font-semibold">
                  Complete barbell sets to record estimated 1RM targets!
                </p>
              )}
            </div>
          </motion.div>
        )}

        {/* ── TAB 3: MEASUREMENTS TAB (Fully functional weight logger) ── */}
        {activeTab === "measurements" && (
          <motion.div
            key="measurements-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            {/* Weight Goal Section */}
            <motion.div
              className="rounded-[--radius-card] glass-card p-5 border border-border"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
            >
              <div className="mb-4 flex items-center justify-between">
                <h2 className="text-sm font-black text-text-primary uppercase tracking-wider">
                  {isAr ? "هدف الوزن" : "Weight Goal"}
                </h2>
                <Target className="h-5 w-5 text-primary" />
              </div>
              
              {measurements.length >= 1 ? (
                <WeightGoalTracker 
                  current={measurements[0].weight || 0}
                  start={measurements[measurements.length - 1].weight || measurements[0].weight || 0}
                  target={isAr ? 75 : 75} // This should ideally come from user profile, but using 75 as a common placeholder
                  isAr={isAr}
                />
              ) : (
                <div className="text-center py-6">
                  <Scale className="h-10 w-10 text-text-muted/20 mx-auto mb-2" />
                  <p className="text-xs text-text-muted uppercase font-bold tracking-wider">
                    {isAr ? "سجل وزنك عشان نتابع الهدف" : "Log your weight to start tracking goals"}
                  </p>
                </div>
              )}
            </motion.div>

            {/* Log weight Button */}
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
                {isAr ? "سجل القياسات" : "Weight & Fat Log"}
              </h3>
              <Button
                size="sm"
                variant="primary"
                onClick={() => setShowAddMeasurement(true)}
              >
                <Plus className="w-4 h-4 mr-1.5" />
                {t.addWeightLog}
              </Button>
            </div>

            {/* Modal for new measurement */}
            {showAddMeasurement && (
              <div className="glass-card p-5 border border-primary/20 bg-primary/5 rounded-xl space-y-4">
                <h4 className="text-xs font-black text-primary uppercase tracking-wider">
                  {isAr ? "ضيف قياسات جديدة" : "Add New Measurement"}
                </h4>
                <form onSubmit={handleAddMeasurementSubmit} className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-text-muted font-bold block mb-1">{t.weightLabel}</label>
                    <input
                      type="number"
                      required
                      placeholder="e.g. 78"
                      value={measurementForm.weight}
                      onChange={(e) => setMeasurementForm({ ...measurementForm, weight: e.target.value })}
                      className="w-full bg-bg-surface border border-border rounded-lg p-2 text-xs text-text-primary"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-text-muted font-bold block mb-1">{t.fatLabel}</label>
                    <input
                      type="number"
                      placeholder="e.g. 15"
                      value={measurementForm.bodyFat}
                      onChange={(e) => setMeasurementForm({ ...measurementForm, bodyFat: e.target.value })}
                      className="w-full bg-bg-surface border border-border rounded-lg p-2 text-xs text-text-primary"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-text-muted font-bold block mb-1">{t.waistLabel}</label>
                    <input
                      type="number"
                      placeholder="e.g. 82"
                      value={measurementForm.waist}
                      onChange={(e) => setMeasurementForm({ ...measurementForm, waist: e.target.value })}
                      className="w-full bg-bg-surface border border-border rounded-lg p-2 text-xs text-text-primary"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-text-muted font-bold block mb-1">{t.chestLabel}</label>
                    <input
                      type="number"
                      placeholder="e.g. 102"
                      value={measurementForm.chest}
                      onChange={(e) => setMeasurementForm({ ...measurementForm, chest: e.target.value })}
                      className="w-full bg-bg-surface border border-border rounded-lg p-2 text-xs text-text-primary"
                    />
                  </div>
                  <div className="col-span-2 flex gap-2 justify-end pt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setShowAddMeasurement(false)}
                    >
                      {t.cancelBtn}
                    </Button>
                    <Button
                      size="sm"
                      variant="primary"
                      type="submit"
                    >
                      {t.saveBtn}
                    </Button>
                  </div>
                </form>
              </div>
            )}

            {/* Weight Chart */}
            {measurements.length > 0 ? (
              <div className="glass-card rounded-[--radius-card] p-5 border border-border space-y-4">
                <h4 className="text-xs font-black text-text-secondary uppercase tracking-wider">
                  {isAr ? "رسم بياني لوزنك" : "Weight Progression Chart"}
                </h4>
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={measurements.slice().reverse()}
                      margin={{ top: 5, right: 5, left: -25, bottom: 0 }}
                    >
                      <defs>
                        <linearGradient id="weightLogGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#CCFF00" stopOpacity={0.25}/>
                          <stop offset="95%" stopColor="#CCFF00" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#27272A" vertical={false} />
                      <XAxis
                        dataKey="date"
                        tickFormatter={(str) => {
                          const date = new Date(str);
                          return isAr
                            ? `${date.getDate()} ${monthsAr[date.getMonth()]}`
                            : `${date.getDate()} ${monthsEn[date.getMonth()].substring(0, 3)}`;
                        }}
                        tick={{ fill: "#A1A1AA", fontSize: 9 }}
                      />
                      <YAxis domain={["auto", "auto"]} tick={{ fill: "#A1A1AA", fontSize: 10 }} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#1C1C1F",
                          border: "1px solid #27272A",
                          borderRadius: 8,
                          fontSize: 11,
                        }}
                        labelStyle={{ color: "#F5F5F7" }}
                        formatter={(value) => [`${value} kg`, isAr ? "الوزن" : "Weight"]}
                      />
                      <Area type="monotone" dataKey="weight" stroke="#CCFF00" strokeWidth={2} fillOpacity={1} fill="url(#weightLogGrad)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            ) : (
              <DataEmptyState
                icon={Scale}
                title="No Measurements Recorded"
                description="Start logging your weight to generate charts!"
              />
            )}

            {/* Historic List */}
            {measurements.length > 0 && (
              <div className="glass-card rounded-[--radius-card] p-5 border border-border space-y-3">
                <h4 className="text-xs font-black text-text-secondary uppercase tracking-wider">
                  {isAr ? "قياساتك اللي فاتت" : "Logged Measurements"}
                </h4>
                <div className="space-y-2">
                  {measurements.map((m) => (
                    <div
                      key={m.id}
                      className="bg-bg-surface-hover border border-border rounded-xl p-3 flex justify-between items-center"
                    >
                      <div>
                        <span className="text-xs font-black text-text-primary">{m.weight} kg</span>
                        <div className="text-[10px] text-text-muted font-semibold font-mono mt-0.5">
                          {new Date(m.date).toLocaleDateString(isAr ? 'ar-EG' : undefined)}
                        </div>
                      </div>
                      <div className="flex gap-4 text-[10px] text-text-secondary font-semibold uppercase">
                        {m.bodyFat && <span>{isAr ? "دهون" : "Fat"}: {m.bodyFat}%</span>}
                        {m.waist && <span>{isAr ? "خصر" : "Waist"}: {m.waist}cm</span>}
                        {m.chest && <span>{isAr ? "صدر" : "Chest"}: {m.chest}cm</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {/* ── TAB 4: PHOTOS TAB (Gorgeous Before/After comparison slider) ── */}
        {activeTab === "photos" && (
          <motion.div
            key="photos-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            {/* Upload widgets */}
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-black text-text-primary uppercase tracking-wider">
                {t.beforeAfterTitle}
              </h3>
              <Button
                variant="primary"
                onClick={() => fileInputRef.current?.click()}
              >
                <Camera className="w-4 h-4 mr-1.5" />
                {t.uploadPhotoBtn}
              </Button>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handlePhotoUpload}
                accept="image/*"
                className="hidden"
              />
            </div>

            {/* Before/After Interactive Comparison slider */}
            {photos.length >= 2 ? (
              <div className="glass-card rounded-[--radius-card] p-5 border border-border space-y-4">
                <div className="flex gap-4 mb-2">
                  <div className="flex-1">
                    <label className="text-[10px] block font-bold text-text-muted mb-1">
                      {isAr ? "صورة قبل" : "Before Photo"}
                    </label>
                    <select
                      value={beforePhotoId}
                      onChange={(e) => setBeforePhotoId(e.target.value)}
                      className="w-full bg-bg-surface border border-border rounded-lg p-2 text-xs text-text-primary"
                    >
                      {photos.map((p) => (
                        <option key={p.id} value={p.id}>
                          {new Date(p.date).toLocaleDateString()}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex-1">
                    <label className="text-[10px] block font-bold text-text-muted mb-1">
                      {isAr ? "صورة بعد" : "After Photo"}
                    </label>
                    <select
                      value={afterPhotoId}
                      onChange={(e) => setAfterPhotoId(e.target.value)}
                      className="w-full bg-bg-surface border border-border rounded-lg p-2 text-xs text-text-primary"
                    >
                      {photos.map((p) => (
                        <option key={p.id} value={p.id}>
                          {new Date(p.date).toLocaleDateString()}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {beforePhoto && afterPhoto && (
                  <div className="relative w-full aspect-square sm:max-w-md mx-auto rounded-2xl overflow-hidden border border-border shadow-2xl select-none">
                    {/* After Image (Background) */}
                    <img
                      src={afterPhoto.url}
                      alt="After progress"
                      className="absolute inset-0 w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute bottom-3 right-3 bg-primary/90 text-primary-text text-[9px] font-black uppercase px-2 py-1 rounded-md z-10">
                      {isAr ? "بعد" : "AFTER"}
                    </div>

                    {/* Before Image (Clip Slider) */}
                    <div
                      className="absolute inset-y-0 left-0 overflow-hidden"
                      style={{ width: `${sliderPos}%` }}
                    >
                      <img
                        src={beforePhoto.url}
                        alt="Before progress"
                        className="absolute inset-y-0 left-0 w-full h-full object-cover"
                        style={{ width: "100%", maxWidth: "none" }}
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute bottom-3 left-3 bg-bg-surface/90 text-text-primary text-[9px] font-black uppercase px-2 py-1 rounded-md z-10">
                        {isAr ? "قبل" : "BEFORE"}
                      </div>
                    </div>

                    {/* Interactive Slider Bar */}
                    <div
                      className="absolute inset-y-0 w-1 bg-primary cursor-ew-resize flex items-center justify-center"
                      style={{ left: `${sliderPos}%` }}
                    >
                      <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-primary-text shadow-lg border-2 border-border">
                        <ChevronsLeftRight className="w-3.5 h-3.5" />
                      </div>
                    </div>

                    {/* Invisible Range Input Overlay */}
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={sliderPos}
                      onChange={(e) => setSliderPos(Number(e.target.value))}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20"
                    />
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-12 border border-dashed border-border rounded-2xl bg-bg-surface/20 p-6 flex flex-col items-center">
                <ImageIcon className="w-12 h-12 text-text-muted mb-3" />
                <p className="text-sm font-bold text-text-secondary">
                  {isAr ? "لازم ترفع صورتين على الأقل عشان تقارن بينهم." : "Please upload at least 2 progress photos to use the interactive slider comparison."}
                </p>
              </div>
            )}

            {/* Photo history grid */}
            {photos.length > 0 && (
              <div className="glass-card rounded-[--radius-card] p-5 border border-border space-y-4">
                <h4 className="text-xs font-black text-text-primary uppercase tracking-wider">
                  {t.photoHistoryTitle}
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {photos.map((p) => (
                    <div
                      key={p.id}
                      className="bg-bg-surface rounded-xl overflow-hidden border border-border relative group aspect-square flex flex-col"
                    >
                      <img
                        src={p.url}
                        alt="Progress snapshot"
                        className="w-full h-full object-cover flex-1"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => deletePhoto(p.id!)}
                          className="bg-red-500/90 text-white p-1.5 rounded-lg hover:bg-red-600 shadow"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <div className="bg-bg-surface-hover p-2 text-center text-[10px] font-bold text-text-secondary border-t border-border font-mono">
                        {new Date(p.date).toLocaleDateString()}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === "history" && (
          <motion.div
            key="history"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="space-y-6"
          >
            <WorkoutHistoryList isAr={isAr} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── IMMERSIVE FULL-BODY RECOVERY MODAL ── */}
      <AnimatePresence>
        {isRecoveryModalOpen && (
          <motion.div
            className="fixed inset-0 z-[120] flex items-center justify-center bg-bg-surface/95 backdrop-blur-md p-4 overflow-y-auto"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="w-full max-w-lg bg-bg-surface border border-border rounded-2xl p-6 shadow-2xl relative space-y-6"
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
            >
              <button
                onClick={() => setIsRecoveryModalOpen(false)}
                className="absolute top-4 right-4 p-2 bg-bg-surface-hover rounded-xl hover:bg-bg-surface-hover text-text-secondary hover:text-text-primary transition-all"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="text-right">
                <div className="flex items-center gap-2 text-primary">
                  <Activity className="w-5 h-5 animate-pulse" />
                  <h3 className="text-lg font-black uppercase tracking-wider">
                    {t.muscleRecoveryTitle} 🩺
                  </h3>
                </div>
                <p className="text-xs text-text-muted font-semibold mt-1">
                  {t.avgRecovery}
                </p>
              </div>

              {/* High precision skeletal outline */}
              <div className="bg-bg-surface rounded-2xl p-4 border border-border shadow-inner flex justify-center">
                <AnatomyModel
                  muscleLevels={Object.entries(muscleRecovery).reduce((acc, [k, v]) => ({ ...acc, [k]: v.percent }), {})}
                  view="both"
                  highlightColor="green"
                  isAr={isAr}
                />
              </div>

              {/* Progress bars of muscles */}
              <div className="space-y-4">
                <h4 className="text-[10px] text-text-muted font-black uppercase tracking-widest text-right">
                  {t.muscleStatusLabel}
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  {Object.entries(muscleRecovery).map(([muscle, stats]) => {
                    const isFresh = stats.percent === 100;
                    let colorClass = "bg-primary";
                    if (stats.percent < 40) colorClass = "bg-red-500";
                    else if (stats.percent < 100) colorClass = "bg-yellow-500";

                    return (
                      <div key={muscle} className="bg-bg-surface-hover/40 p-3 rounded-xl border border-border flex flex-col justify-between">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-xs font-black text-text-primary">{getMuscleLabel(muscle)}</span>
                          <span className="text-[10px] text-text-muted font-bold font-mono">{stats.percent}%</span>
                        </div>
                        <div className="h-1.5 w-full bg-bg-surface rounded-full overflow-hidden mb-1">
                          <div className={cn("h-full rounded-full", colorClass)} style={{ width: `${stats.percent}%` }} />
                        </div>
                        <span className="text-[8px] text-text-muted font-bold uppercase font-mono">
                          {isFresh ? t.readyToLift : t.hoursRemaining(stats.hoursLeft)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
