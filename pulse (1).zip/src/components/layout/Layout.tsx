import { ReactNode, useRef, useState, useEffect } from "react";
import { Link, useLocation } from "@tanstack/react-router";
import { Home, Dumbbell, Activity, User, Utensils, Globe, ArrowUp } from "lucide-react";
import { ToastContainer } from "@/components/ui/Toast";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/utils/cn";
import { useSettingsStore } from "@/store/useSettingsStore";
import { useWorkoutStore } from "@/store/useWorkoutStore";

function NavItem({ to, icon: Icon, label }: { to: string; icon: any; label: string }) {
  const triggerHaptic = () => {
    if (typeof navigator !== "undefined" && navigator.vibrate) {
      navigator.vibrate(50);
    }
  };

  return (
    <Link
      to={to}
      onClick={triggerHaptic}
      className="group relative flex flex-1 flex-col items-center p-3 text-text-muted hover:text-text-primary [&.active]:text-primary transition-colors animate-fade-in"
    >
      <div className="absolute top-0 w-8 h-0.5 bg-primary scale-x-0 group-[.active]:scale-x-100 transition-transform origin-center rounded-b-full shadow-[0_0_8px_rgba(204,255,0,0.8)]" />
      <Icon size={22} strokeWidth={2.5} className="mt-1" />
      <span className="text-[10px] mt-1 font-bold tracking-wide text-center uppercase">
        {label}
      </span>
    </Link>
  );
}

export default function Layout({ children }: { children: ReactNode }) {
  const mainRef = useRef<HTMLElement>(null);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const location = useLocation();
  const { language } = useSettingsStore();
  const activeWorkout = useWorkoutStore((s) => s.activeWorkout);

  const isAr = language === "ar";

  const [showHeader, setShowHeader] = useState(true);
  const lastScrollY = useRef(0);

  useEffect(() => {
    if (mainRef.current) {
      mainRef.current.scrollTo(0, 0);
    }
    setShowHeader(true);
    lastScrollY.current = 0;
  }, [location.pathname]);

  const handleScroll = (e: React.UIEvent<HTMLElement>) => {
    const currentScrollTop = e.currentTarget.scrollTop;
    setShowScrollTop(currentScrollTop > 300);

    // Always show header at the very top
    if (currentScrollTop <= 10) {
      setShowHeader(true);
      lastScrollY.current = currentScrollTop;
      return;
    }

    // Only toggle header if scrolled past a small threshold to avoid micro-flickering
    if (Math.abs(currentScrollTop - lastScrollY.current) > 10) {
      if (currentScrollTop > lastScrollY.current && currentScrollTop > 80) {
        // Scrolling down -> hide header
        setShowHeader(false);
      } else {
        // Scrolling up -> show header
        setShowHeader(true);
      }
      lastScrollY.current = currentScrollTop;
    }
  };

  const scrollToTop = () => {
    if (mainRef.current) {
      mainRef.current.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  return (
    <div className="flex justify-center bg-bg-surface min-h-screen">
      <div
        dir={isAr ? "rtl" : "ltr"}
        className="flex flex-col h-[100dvh] w-full max-w-md bg-bg text-text-primary relative shadow-2xl border-x border-border overflow-hidden"
      >
        <ToastContainer />
        
        {/* Header with Title and Safe Area Top Padding - Hide on Scroll Down, Show on Scroll Up */}
        <header
          className={cn(
            "absolute top-0 left-0 right-0 pt-[env(safe-area-inset-top)] bg-bg-surface-hover backdrop-blur-lg border-b border-border z-40 transition-transform duration-300 ease-in-out",
            showHeader ? "translate-y-0" : "-translate-y-full"
          )}
        >
          <div className="h-14 flex items-center justify-center px-4">
            <div className="flex items-center justify-center gap-2">
              <img src="/src/assets/images/relift_logo_1784576563070.jpg" alt="ReLift Logo" className="w-8 h-8 rounded-lg object-cover border border-primary/30" />
              <h1 className="text-xl font-black italic tracking-widest uppercase text-primary drop-shadow-[0_0_8px_rgba(204,255,0,0.4)]">
                ReLift
              </h1>
            </div>
          </div>
        </header>

        <main
          ref={mainRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto scroll-smooth no-scrollbar pt-[calc(3.5rem+env(safe-area-inset-top))] pl-[env(safe-area-inset-left)] pr-[env(safe-area-inset-right)]"
        >
          <div className="px-4 py-6">{children}</div>
        </main>

        <AnimatePresence>
          {showScrollTop && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              onClick={scrollToTop}
              className="absolute bottom-24 right-4 z-40 p-3 rounded-full bg-primary text-black font-black shadow-[0_0_16px_rgba(204,255,0,0.3)] hover:scale-105 active:scale-95 transition-transform"
            >
              <ArrowUp className="w-5 h-5" />
            </motion.button>
          )}
        </AnimatePresence>

        {/* ── Start Workout floating tooltip pointing to 'Exercises' tab ── */}
        <AnimatePresence>
          {location.pathname === "/" && !activeWorkout && (
            <Link to="/exercises">
              <motion.div
                initial={{ opacity: 0, y: 15, scale: 0.9, x: "-50%" }}
                animate={{ opacity: 1, y: [0, -6, 0], scale: 1 }}
                exit={{ opacity: 0, y: 15, scale: 0.9 }}
                transition={{
                  opacity: { duration: 0.2 },
                  scale: { duration: 0.2 },
                  y: {
                    repeat: Infinity,
                    duration: 2.2,
                    ease: "easeInOut"
                  }
                }}
                className="absolute bottom-[4.8rem] left-[25%] z-[150] bg-white text-black text-[11px] font-black px-3.5 py-2 rounded-xl shadow-[0_10px_30px_rgba(0,0,0,0.8)] flex items-center gap-1.5 whitespace-nowrap cursor-pointer hover:bg-bg-surface-hover active:scale-95 transition-all"
              >
                <span className="uppercase tracking-wider">
                  {isAr ? "إبدأ تمرينة جديدة" : "Start a new workout"}
                </span>
                <span className="text-zinc-900 font-bold animate-pulse text-xs">◀</span>
              </motion.div>
            </Link>
          )}
        </AnimatePresence>

        {/* Bottom Nav with Safe Area Bottom Padding */}
        <nav className="shrink-0 w-full bg-bg-surface-hover backdrop-blur-md border-t border-border flex flex-col justify-end z-50">
          <div className="flex justify-between items-center h-[4.5rem]">
            <NavItem to="/" icon={Home} label={isAr ? "الرئيسية" : "Home"} />
            <NavItem to="/exercises" icon={Dumbbell} label={isAr ? "التمارين" : "Exercises"} />
            <NavItem to="/feed" icon={Globe} label={isAr ? "الناس" : "Feed"} />
            <NavItem to="/nutrition" icon={Utensils} label={isAr ? "أكلك" : "Nutrition"} />
            <NavItem to="/stats" icon={Activity} label={isAr ? "تطورك" : "Stats"} />
            <NavItem to="/profile" icon={User} label={isAr ? "بروفايلك" : "Profile"} />
          </div>
          <div className="h-[env(safe-area-inset-bottom)] bg-transparent w-full" />
        </nav>
      </div>
    </div>
  );
}
