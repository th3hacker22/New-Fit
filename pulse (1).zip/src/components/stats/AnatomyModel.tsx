import React from "react";
import { motion } from "framer-motion";
import { FRONT, BACK, FRONT_BODY, BACK_BODY } from "../AnatomyMap";

interface AnatomyModelProps {
  muscleLevels: Record<string, number>; // values 0 to 100
  view: "front" | "back" | "both";
  highlightColor?: "red" | "green" | "cyan" | "yellow";
  isAr?: boolean;
}

// Maps any premium muscle group ID to one of the 6 primary categories
const getCategoryForMuscleId = (id: string): string => {
  const lowercaseId = id.toLowerCase();
  
  if (lowercaseId.includes("chest")) return "Chest";
  if (
    lowercaseId.includes("traps") ||
    lowercaseId.includes("back") ||
    lowercaseId.includes("lats") ||
    lowercaseId.includes("neck")
  ) {
    return "Back";
  }
  if (
    lowercaseId.includes("quad") ||
    lowercaseId.includes("femoris") ||
    lowercaseId.includes("vmo") ||
    lowercaseId.includes("adductor") ||
    lowercaseId.includes("gastrocnemius") ||
    lowercaseId.includes("tibialis") ||
    lowercaseId.includes("soleus") ||
    lowercaseId.includes("glute") ||
    lowercaseId.includes("ham") ||
    lowercaseId.includes("gastroc")
  ) {
    return "Legs";
  }
  if (lowercaseId.includes("delt")) return "Shoulders";
  if (
    lowercaseId.includes("biceps") ||
    lowercaseId.includes("forearm") ||
    lowercaseId.includes("triceps")
  ) {
    return "Arms";
  }
  if (
    lowercaseId.includes("abs") ||
    lowercaseId.includes("obliques") ||
    lowercaseId.includes("core")
  ) {
    return "Core";
  }
  return "";
};

export default function AnatomyModel({
  muscleLevels,
  view = "both",
  highlightColor = "green",
  isAr = false,
}: AnatomyModelProps) {
  // Helper to resolve color based on recovery percentage or workout active status
  const getMuscleColor = (id: string) => {
    const category = getCategoryForMuscleId(id);
    const inactiveColor = "rgba(156, 163, 175, 0.4)"; // gray-400 with opacity for better visibility
    
    if (!category) return inactiveColor;
    const level = muscleLevels[category] ?? 0;
    
    // 1. Worked-intensity mode (highlightColor === "red")
    if (highlightColor === "red") {
      if (level === 0) {
        return inactiveColor; // not worked
      }
      // worked: return glowing gradient corresponding to level
      return `rgba(101, 163, 13, ${(0.4 + (level / 100) * 0.6).toFixed(2)})`; // bright active primary
    }

    // 2. Recovery theme mode (default green/sore theme)
    if (level === 0) {
      return "rgba(220, 38, 38, 0.8)"; // sore red
    }
    if (level === 100) {
      return "rgba(101, 163, 13, 0.85)"; // recovered primary green
    }
    if (highlightColor === "cyan") {
      return `rgba(2, 132, 199, ${((100 - level) / 100).toFixed(2)})`;
    }

    // Gradient recovery status
    if (level >= 90) return "rgba(101, 163, 13, 0.85)";
    if (level >= 60) return "rgba(217, 119, 6, 0.75)";
    return "rgba(220, 38, 38, 0.8)";
  };

  const drawFront = () => (
    <svg viewBox="0 0 676.49 1203.49" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto max-h-[220px] md:max-h-[280px] mx-auto drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)]">
      {/* Grey Outline Body Paths */}
      <g opacity="0.6">
        {FRONT_BODY.map((d, i) => (
          <path
            key={i}
            d={d}
            fill="none"
            stroke="rgba(107, 114, 128, 0.8)"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        ))}
      </g>
      {/* Detailed Front Muscles */}
      {FRONT.map((m) => {
        const fillCol = getMuscleColor(m.id);
        const isActive = fillCol !== "rgba(156, 163, 175, 0.4)";
        return (
          <g key={m.id}>
            {m.paths.map((d, i) => (
              <path
                key={i}
                d={d}
                fill={fillCol}
                stroke={isActive ? m.color : "rgba(107, 114, 128, 0.5)"}
                strokeWidth={isActive ? 2 : 1}
                strokeLinejoin="round"
                style={{ transition: "all 0.3s ease" }}
              />
            ))}
          </g>
        );
      })}
    </svg>
  );

  const drawBack = () => (
    <svg viewBox="0 0 676.49 1203.49" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto max-h-[220px] md:max-h-[280px] mx-auto drop-shadow-[0_4px_12px_rgba(0,0,0,0.5)]">
      {/* Grey Outline Body Paths */}
      <g opacity="0.6">
        {BACK_BODY.map((d, i) => (
          <path
            key={i}
            d={d}
            fill="none"
            stroke="rgba(107, 114, 128, 0.8)"
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        ))}
      </g>
      {/* Detailed Back Muscles */}
      {BACK.map((m) => {
        const fillCol = getMuscleColor(m.id);
        const isActive = fillCol !== "rgba(156, 163, 175, 0.4)";
        return (
          <g key={m.id}>
            {m.paths.map((d, i) => (
              <path
                key={i}
                d={d}
                fill={fillCol}
                stroke={isActive ? m.color : "rgba(107, 114, 128, 0.5)"}
                strokeWidth={isActive ? 2 : 1}
                strokeLinejoin="round"
                style={{ transition: "all 0.3s ease" }}
              />
            ))}
          </g>
        );
      })}
    </svg>
  );

  return (
    <div className="flex flex-row justify-center items-center gap-4 md:gap-8 w-full p-2 select-none">
      {(view === "front" || view === "both") && (
        <div className="flex flex-col items-center flex-1 max-w-[140px]">
          <span className="text-[10px] text-text-muted font-extrabold tracking-widest uppercase mb-2">
            {isAr ? "الأمام" : "ANTERIOR"}
          </span>
          <div className="w-full border border-border bg-bg-surface-hover rounded-2xl p-2 md:p-3 shadow-inner backdrop-blur-md">
            {drawFront()}
          </div>
        </div>
      )}
      {(view === "back" || view === "both") && (
        <div className="flex flex-col items-center flex-1 max-w-[140px]">
          <span className="text-[10px] text-text-muted font-extrabold tracking-widest uppercase mb-2">
            {isAr ? "الخلف" : "POSTERIOR"}
          </span>
          <div className="w-full border border-border bg-bg-surface-hover rounded-2xl p-2 md:p-3 shadow-inner backdrop-blur-md">
            {drawBack()}
          </div>
        </div>
      )}
    </div>
  );
}
