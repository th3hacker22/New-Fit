import { useState, useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  User,
  Settings,
  Scale,
  ChevronRight,
  Dumbbell,
  Flame,
  Camera,
} from "lucide-react";
import { getWorkoutStreak, getTotalStats, db } from "@/db";
import { useSettingsStore } from "@/store/useSettingsStore";
import { useAuthStore } from "@/store/useAuthStore";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";
import { pushToCloud } from "@/lib/syncEngine";
import { useAchievementsStore } from "@/store/useAchievementsStore";
import { ACHIEVEMENTS } from "@/data/achievements";
import AchievementBadge from "@/components/AchievementBadge";
import { useToastStore } from "@/store/useToastStore";
import { Button } from "@/components/ui/Button";
import { uid } from "@/utils/id";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.4, ease: "easeOut" as const },
  }),
};

export default function ProfilePage() {
  const [streak, setStreak] = useState(0);
  const [totalWorkouts, setTotalWorkouts] = useState(0);
  const [latestWeight, setLatestWeight] = useState<number | null>(null);
  const ramadanMode = useSettingsStore((s) => s.ramadanMode);
  const language = useSettingsStore((s) => s.language);
  const isAr = language === "ar";
  const { user } = useAuthStore();
  const [syncing, setSyncing] = useState(false);
  const { unlockedList, loadUnlocked } = useAchievementsStore();

  const [avatarEmoji, setAvatarEmoji] = useState(() => {
    return localStorage.getItem("relift-profile-avatar") || "🏋️‍♂️";
  });

  const emojis = ["🏋️‍♂️", "🏋️‍♀️", "💪", "🏃‍♂️", "🏃‍♀️", "🤸‍♂️", "🤸‍♀️", "🦁", "⚡", "🔥"];

  useEffect(() => {
    async function loadData() {
      const [streakData, statsData, measurements] = await Promise.all([
        getWorkoutStreak(),
        getTotalStats(),
        db.bodyMeasurements.orderBy("date").reverse().first(),
      ]);

      setStreak(streakData);
      setTotalWorkouts(statsData.totalWorkouts);
      setLatestWeight(measurements?.weight ?? null);

      loadUnlocked();
    }
    loadData();
  }, [loadUnlocked]);

  const handleCycleAvatar = () => {
    const currentIndex = emojis.indexOf(avatarEmoji);
    const nextIndex = (currentIndex + 1) % emojis.length;
    const nextEmoji = emojis[nextIndex];
    setAvatarEmoji(nextEmoji);
    localStorage.setItem("relift-profile-avatar", nextEmoji);
    useToastStore.getState().addToast("success", isAr ? "غيرنا الصورة الرمزية بنجاح! 😎" : "Avatar changed successfully! 😎");
  };

  const handleFreezeStreak = async () => {
    const confirmMsg = isAr 
      ? "عايز تجمد الستريك للنهاردة؟ ده هيضيف حصة وهمية عشان يحمي الاستمرارية بتاعتك من غير ما يأثر على أرقام وحجم تمرينك."
      : "Freeze your streak for today? This adds a dummy session to protect your streak without adding to your volume.";

    if (confirm(confirmMsg)) {
      const dbDate = new Date().toISOString();
      await db.workoutSessions.add({
        id: uid(),
        name: isAr ? "تجميد الستريك ❄️" : "Streak Freeze ❄️",
        date: dbDate,
        duration: 0,
        exercises: [],
        completed: true,
        isFreeze: true,
        createdAt: dbDate,
        updatedAt: dbDate,
      });
      useToastStore
        .getState()
        .addToast("success", isAr ? "تم تجميد الستريك للنهاردة! ❄️" : "Streak frozen for today! ❄️");
      const streakData = await getWorkoutStreak();
      setStreak(streakData);
    }
  };

  const menuItems = [
    {
      icon: Scale,
      label: isAr ? "وزن وقياسات جسمك ⚖️" : "Body Metrics",
      description: latestWeight
        ? (isAr ? `${latestWeight} كجم` : `${latestWeight} kg`)
        : (isAr ? "سجل وزنك ومقاساتك" : "Log your measurements"),
      color: "text-primary",
      href: "/body",
    },
    {
      icon: Camera,
      label: isAr ? "صور التطور والمقارنة 📸" : "Progress Photos",
      description: isAr ? "تابع تغيير شكل جسمك" : "Track your transformation",
      color: "text-warning",
      href: "/body",
    },
    {
      icon: Settings,
      label: isAr ? "إعدادات الأبلكيشن ⚙️" : "Settings",
      description: ramadanMode
        ? (isAr ? "وضع رمضان شغال 🌙" : "Ramadan Mode Active 🌙")
        : (isAr ? "ظبط الأبلكيشن على مزاجك" : "Customize application"),
      color: "text-text-secondary",
      href: "/settings",
    },
  ];

  // Game level based on completed workouts
  const getLevelInfo = (workouts: number) => {
    const level = Math.floor(workouts / 5) + 1;
    const xp = workouts % 5;
    const progress = (xp / 5) * 100;
    
    let title = isAr ? "عضو جديد 🔥" : "New Member 🔥";
    if (level >= 3 && level <= 5) title = isAr ? "مواظب الصالة 💪" : "Gym Regular 💪";
    else if (level >= 6 && level <= 10) title = isAr ? "وحش التمرين 🦁" : "Workout Beast 🦁";
    else if (level >= 11 && level <= 20) title = isAr ? "فورمة الساحل 🏝️" : "Shredded Form 🏝️";
    else if (level >= 21 && level <= 50) title = isAr ? "كابتن حقيقي 🎖️" : "True Captain 🎖️";
    else if (level > 50) title = isAr ? "أسطورة الجيم 👑" : "Gym Legend 👑";
    
    return { level, progress, xp, nextLevelXp: 5, title };
  };

  const levelInfo = getLevelInfo(totalWorkouts);

  const getLocalizedAchievement = (id: string, enTitle: string, enDesc: string) => {
    const map: Record<string, { title: string; desc: string }> = {
      first_workout: {
        title: "أول خطوة 🏋️‍♂️",
        desc: "سجلت أول تمرينة في رحلة الفورمة.",
      },
      "3_day_streak": {
        title: "جامد وعافر 🔥",
        desc: "سجلت ٣ أيام تمرين ورا بعض.",
      },
      "7_day_streak": {
        title: "محدش يقدر يوقفك ⚡",
        desc: "حققت ستريك ٧ أيام متواصلة.",
      },
      "10k_tonnage": {
        title: "وحش الأوزان 💪",
        desc: "شلت ١٠,٠٠٠ كجم توتال في أسبوع واحد.",
      },
      "100_workouts": {
        title: "البطل المحترف 👑",
        desc: "قفلت ١٠٠ تمرينة، مبروك اللقب!",
      },
      night_owl: {
        title: "خفاش الجيم 🦉",
        desc: "اتمرنت في نص الليل (من ١٢ لـ ٤ الفجر).",
      },
      early_bird: {
        title: "وحش الصبح بدري 🌅",
        desc: "صحيت وفجرت طاقة من ٤ لـ ٨ الصبح.",
      },
    };
    return map[id] || { title: enTitle, desc: enDesc };
  };

  return (
    <div className="space-y-6" dir={isAr ? "rtl" : "ltr"}>
      {/* ── Page Title ── */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <h1 className="text-xl font-bold text-text-primary uppercase tracking-wider">
          {isAr ? "بروفايلك يا بطل 👤" : "Profile"}
        </h1>
        <p className="mt-1 text-sm text-text-secondary">
          {isAr ? "تابع أرقامك، قوتك، وتطور فورمتك من هنا" : "Manage your info and track progress"}
        </p>
      </motion.div>

      {/* ── Profile Card ── */}
      <motion.div
        className="glass-card relative overflow-hidden rounded-[--radius-card] p-6"
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={0}
      >
        <div className="absolute -left-10 -top-10 h-40 w-40 rounded-full bg-primary/10 blur-3xl" />

        <div className="relative z-10 flex items-center gap-4">
          <div className="relative">
            <button
              onClick={handleCycleAvatar}
              className="flex h-16 w-16 items-center justify-center rounded-full bg-primary-muted shrink-0 text-3xl border border-primary/30 shadow-[0_0_15px_rgba(204,255,0,0.15)] hover:scale-105 active:scale-95 transition-all relative group"
              title={isAr ? "اضغط لتغيير الصورة الرمزية" : "Click to change avatar"}
            >
              {avatarEmoji}
              <div className="absolute -bottom-1 -right-1 bg-primary text-black rounded-full p-0.5 text-[9px] font-bold opacity-0 group-hover:opacity-100 transition-opacity">
                🔄
              </div>
            </button>
            {ramadanMode && (
              <motion.div
                className="absolute -top-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-warning text-xs"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 400, damping: 15 }}
              >
                🌙
              </motion.div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-text-primary truncate">
                {user?.email || (isAr ? "وحش ري‌ليفت ⚡" : "ReLift User ⚡")}
              </h2>
            </div>
            <p className="text-sm text-text-secondary truncate">
              {totalWorkouts > 0
                ? (isAr ? `قفلت ${totalWorkouts} تمرينة عاش! 💪` : `${totalWorkouts} completed workouts`)
                : (isAr ? "ابدأ فورمتك والعب أول تمرينة 🚀" : "Start your fitness journey")}
            </p>
          </div>
        </div>

        {/* Level Progression Bar */}
        <div className="mt-5 border-t border-border/30 pt-4">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-bold text-primary flex items-center gap-2">
              <span className="bg-primary/20 px-2.5 py-0.5 rounded-md text-[10px] text-primary border border-primary/20">
                {isAr ? `مستوى ${levelInfo.level}` : `LVL ${levelInfo.level}`}
              </span>
              <span className="text-text-primary text-[12px] font-semibold">{levelInfo.title}</span>
            </span>
            <span className="text-text-muted text-[10px] font-mono">
              {levelInfo.xp} / {levelInfo.nextLevelXp} {isAr ? "لتطوير المستوى" : "to next level"}
            </span>
          </div>
          <div className="h-2 w-full bg-bg-elevated rounded-full overflow-hidden border border-border/10">
            <motion.div
              className="h-full bg-gradient-to-r from-primary to-lime-400"
              initial={{ width: 0 }}
              animate={{ width: `${levelInfo.progress}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
            />
          </div>
        </div>

        <div className="mt-5 flex gap-2">
          {user ? (
            <>
              <Button
                onClick={async () => {
                  setSyncing(true);
                  await pushToCloud(user.uid);
                  setSyncing(false);
                }}
                disabled={syncing}
                variant="outline"
                className="flex-1 py-2.5 text-sm"
              >
                {syncing ? (isAr ? "بالمزامنة..." : "Syncing...") : (isAr ? "ارفع أرقامك ☁️" : "Sync Now")}
              </Button>
              <Button
                onClick={() => {
                  if (auth) signOut(auth);
                }}
                variant="danger"
                className="flex-1 py-2.5 text-sm"
              >
                {isAr ? "تسجيل خروج 🚶‍♂️" : "Logout"}
              </Button>
            </>
          ) : (
            <Button
              variant="primary"
              className="w-full h-10"
              onClick={() => window.location.href = "/auth"}
            >
              {isAr ? "دخول / حساب جديد 👋" : "Login / Signup"}
            </Button>
          )}
        </div>
      </motion.div>

      {/* ── Stats Summary ── */}
      <motion.div
        className="grid grid-cols-3 gap-3"
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={1}
      >
        <div className="glass-card flex flex-col items-center gap-1 rounded-[--radius-card] p-3 text-center">
          <Dumbbell className="h-5 w-5 text-primary" />
          <p className="text-lg font-bold text-text-primary">{totalWorkouts}</p>
          <p className="text-[10px] text-text-muted uppercase tracking-wider">
            {isAr ? "التمارين" : "Workouts"}
          </p>
        </div>
        <div className="glass-card flex flex-col items-center gap-1 rounded-[--radius-card] p-3 text-center relative group">
          <Flame className="h-5 w-5 text-warning" />
          <p className="text-lg font-bold text-text-primary">{streak}</p>
          <div className="flex flex-col items-center">
            <p className="text-[10px] text-text-muted uppercase tracking-wider mb-1">
              {isAr ? "الاستمرارية 🔥" : "Streak 🔥"}
            </p>
            <button
              onClick={handleFreezeStreak}
              className="text-[10px] bg-sky-500/10 text-sky-400 border border-sky-500/20 px-2 py-0.5 rounded-full hover:bg-sky-500/20 transition-colors uppercase tracking-wider font-bold"
            >
              {isAr ? "تجميد ❄️" : "Freeze"}
            </button>
          </div>
        </div>
        <div className="glass-card flex flex-col items-center gap-1 rounded-[--radius-card] p-3 text-center">
          <Scale className="h-5 w-5 text-success" />
          <p className="text-lg font-bold text-text-primary">
            {latestWeight ?? "—"}
          </p>
          <p className="text-[10px] text-text-muted uppercase tracking-wider">
            {isAr ? "آخر وزن" : "kg"}
          </p>
        </div>
      </motion.div>

      {/* ── Achievements ── */}
      <motion.div
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={1.5}
        className="space-y-4"
      >
        <h3 className="text-sm font-bold uppercase tracking-wider text-text-primary px-1">
          {isAr ? "إنجازاتك وبطولاتك 🏆" : "Achievements"}
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {ACHIEVEMENTS.map((ach) => {
            const unlocked = unlockedList.find(
              (u) => u.achievementId === ach.id,
            );
            const localized = isAr ? getLocalizedAchievement(ach.id, ach.title, ach.description) : { title: ach.title, desc: ach.description };
            return (
              <AchievementBadge
                key={ach.id}
                title={localized.title}
                description={localized.desc}
                iconName={ach.iconName}
                isUnlocked={!!unlocked}
                unlockedAt={unlocked?.unlockedAt}
              />
            );
          })}
        </div>
      </motion.div>

      {/* ── Menu Items ── */}
      <motion.div
        className="space-y-2 pb-6"
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={2}
      >
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.label} to={item.href} className="block">
              <div className="glass-card flex w-full items-center gap-4 rounded-[--radius-card] p-4 transition-all duration-200 hover:ring-1 hover:ring-primary/20 active:scale-[0.98]">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-bg-elevated">
                  <Icon className={`h-5 w-5 ${item.color}`} />
                </div>
                <div className={`flex-1 min-w-0 ${isAr ? "text-right" : "text-left"}`}>
                  <p className="text-sm font-medium text-text-primary truncate uppercase tracking-wider">
                    {item.label}
                  </p>
                  {item.description && (
                    <p className="text-xs text-text-muted truncate">
                      {item.description}
                    </p>
                  )}
                </div>
                <ChevronRight className={`h-5 w-5 text-text-muted shrink-0 ${isAr ? "rotate-180" : ""}`} />
              </div>
            </Link>
          );
        })}
      </motion.div>

      {/* ── Ramadan Banner ── */}
      {ramadanMode && (
        <motion.div
          className="glass-card rounded-[--radius-card] p-4 border border-warning/20 bg-warning/5"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex items-center gap-3">
            <span className="text-2xl">🌙</span>
            <div className="min-w-0">
              <p className="text-sm font-bold text-warning uppercase tracking-wider truncate">
                {isAr ? "رمضان كريم يا بطل! 🌙" : "Ramadan Mubarak!"}
              </p>
              <p className="text-xs text-text-muted truncate">
                {isAr ? "حافظ على قوتك وفورمتك في الشهر الكريم" : "Stay fit during the holy month"}
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* ── App Version ── */}
      <motion.p
        className="text-center text-xs text-text-muted pb-8"
        variants={fadeUp}
        initial="hidden"
        animate="visible"
        custom={3}
      >
        ReLift v1.0.0
      </motion.p>
    </div>
  );
}

