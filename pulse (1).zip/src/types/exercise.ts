import { translateExerciseNameToEgyptian } from "../utils/egyptianGymDictionary";
// ── Exercise Types from hasaneyldrm/exercises-dataset ──

export interface ExerciseRaw {
  id: string;
  name: string;
  category: string;
  body_part: string;
  equipment: string;
  instructions: {
    en: string;
    tr: string;
  };
  instruction_steps?: {
    en: string[];
    tr: string[];
  };
  muscle_group: string;
  secondary_muscles: string[];
  target: string;
  image: string;
  gif_url: string;
  created_at: string;
}

export interface Exercise {
  id: string;
  name: string;
  category: string;
  bodyPart: string;
  equipment: string;
  instructions: string;
  instructionSteps: string[];
  muscleGroup: string;
  secondaryMuscles: string[];
  target: string;
  imageUrl: string;
  gifUrl: string;
}

// ── Base URL for media ──
export const MEDIA_BASE_URL =
  "https://raw.githubusercontent.com/hasaneyldrm/exercises-dataset/main";

// ── Transform raw exercise to our format ──
export function transformExercise(raw: ExerciseRaw): Exercise {
  // Translate to Egyptian Arabic
  const arName = translateExerciseNameToEgyptian(raw.name);
  const arBodyPart = translateExerciseNameToEgyptian(raw.body_part);
  const arEquipment = translateExerciseNameToEgyptian(raw.equipment);
  const arTarget = translateExerciseNameToEgyptian(raw.target);
  const arCategory = translateExerciseNameToEgyptian(raw.category);
  const arMuscleGroup = translateExerciseNameToEgyptian(raw.muscle_group);

  return {
    id: raw.id,
    name: arName,
    category: arCategory,
    bodyPart: arBodyPart,
    equipment: arEquipment,
    instructions: raw.instructions.en,
    instructionSteps: raw.instruction_steps?.en || [raw.instructions.en],
    muscleGroup: arMuscleGroup,
    secondaryMuscles: raw.secondary_muscles.map(translateExerciseNameToEgyptian),
    target: arTarget,
    imageUrl: `${MEDIA_BASE_URL}/${raw.image}`,
    gifUrl: `${MEDIA_BASE_URL}/${raw.gif_url}`,
  };
}
